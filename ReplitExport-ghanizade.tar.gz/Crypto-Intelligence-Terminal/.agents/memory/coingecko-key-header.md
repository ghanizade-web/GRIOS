---
name: CoinGecko key header
description: Provider-specific header behavior for the live CoinGecko API connection.
---

Use the CoinGecko Demo key in the `x-cg-demo-api-key` request header. Do not send both Demo and Pro API-key headers in the same request: the provider rejected that combination even when the key itself was valid.

**Why:** The live connection was initially returning HTTP 400 until the request was narrowed to the compatible header.

**How to apply:** Keep provider authentication isolated in one adapter/helper so a future Pro-key or alternate exchange connector can be introduced without changing route handlers.