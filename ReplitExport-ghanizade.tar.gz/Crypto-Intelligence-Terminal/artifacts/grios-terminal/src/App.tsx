import { type ReactNode, useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { Activity, AlertTriangle, ArrowDownRight, ArrowUpRight, BarChart3, BrainCircuit, ChevronRight, Database, Gauge, LayoutDashboard, Menu, RefreshCw, Search, Server, ShieldAlert, SlidersHorizontal, Sparkles, Wifi } from 'lucide-react';
import { Link, Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { getGetConnectionStatusQueryKey, getGetCryptoAlphaQueryKey, getHealthCheckQueryKey, useGetConnectionStatus, useGetCryptoAlpha, useHealthCheck, type AlphaOpportunity, type ConnectionStatus } from '@workspace/api-client-react';
import NotFound from '@/pages/not-found';
import AiPage from '@/pages/ai';

const queryClient = new QueryClient();

const formatMoney = (value: number | null, compact = true) => {
  if (value === null || value === undefined) return '—';
  if (!compact) return `$${value.toLocaleString(undefined, { maximumFractionDigits: 0 })}`;
  if (value >= 1e9) return `$${(value / 1e9).toFixed(2)}B`;
  if (value >= 1e6) return `$${(value / 1e6).toFixed(1)}M`;
  if (value >= 1e3) return `$${(value / 1e3).toFixed(1)}K`;
  return `$${value.toLocaleString(undefined, { maximumFractionDigits: 2 })}`;
};
const formatPct = (value: number | null) => value === null || value === undefined ? '—' : `${value >= 0 ? '+' : ''}${value.toFixed(1)}%`;
const shortTime = (value?: string) => value ? new Date(value).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '—';

function StatusPill({ status }: { status?: string }) {
  const live = status === 'live';
  const limited = status === 'rate_limited';
  return <span className={`inline-flex items-center gap-1.5 rounded-sm border px-2 py-1 text-[10px] font-bold uppercase tracking-[.14em] ${live ? 'border-[#9edb3d]/30 bg-[#9edb3d]/10 text-[#b8ed64]' : limited ? 'border-[#e1ab50]/30 bg-[#e1ab50]/10 text-[#e1ab50]' : 'border-[#e16762]/30 bg-[#e16762]/10 text-[#ed817a]'}`}><span className={`h-1.5 w-1.5 rounded-full ${live ? 'bg-[#b8ed64] shadow-[0_0_8px_#b8ed64]' : limited ? 'bg-[#e1ab50]' : 'bg-[#ed817a]'}`} />{status?.replace('_', ' ') || 'unknown'}</span>;
}

function Shell({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  const [open, setOpen] = useState(false);
  useEffect(() => {
    const openNav = () => setOpen(true);
    document.addEventListener('grios:open-nav', openNav);
    return () => document.removeEventListener('grios:open-nav', openNav);
  }, []);
  const nav = [{ href: '/', label: 'Terminal', icon: LayoutDashboard }, { href: '/alpha', label: 'Alpha scanner', icon: BarChart3 }, { href: '/ai', label: 'Autonomous CIO', icon: BrainCircuit }];
  return <div className="terminal-noise min-h-[100dvh] bg-[#0d1118] text-[#e9e7df]">
    <aside className={`fixed inset-y-0 left-0 z-50 flex w-[236px] flex-col border-r border-[#202a35] bg-[#0a0e14] transition-transform duration-300 lg:translate-x-0 ${open ? 'translate-x-0' : '-translate-x-full'}`}>
      <div className="flex h-[76px] items-center border-b border-[#202a35] px-6">
        <div className="mr-3 flex h-8 w-8 items-center justify-center border border-[#b8ed64]/60 text-[#b8ed64]"><span className="text-[15px] font-extrabold">G</span></div>
        <div><div className="font-mono text-[15px] font-medium tracking-[.27em] text-[#f0eee6]">GRIOS</div><div className="mt-0.5 text-[8px] font-bold uppercase tracking-[.22em] text-[#697786]">Intelligence terminal</div></div>
      </div>
      <div className="px-4 pt-7"><div className="mb-3 px-2 text-[9px] font-bold uppercase tracking-[.2em] text-[#566371]">Workspace</div>
        <nav className="space-y-1">{nav.map(({ href, label, icon: Icon }) => <Link key={href} href={href} data-testid={`link-nav-${label.toLowerCase().replace(' ', '-')}`} onClick={() => setOpen(false)} className={`group flex items-center justify-between rounded-sm border px-3 py-3 text-[12px] font-semibold transition-colors ${location === href ? 'border-[#b8ed64]/25 bg-[#b8ed64]/[.08] text-[#c8f27d]' : 'border-transparent text-[#8793a0] hover:border-[#283440] hover:bg-[#151c24] hover:text-[#ece9df]'}`}><span className="flex items-center gap-3"><Icon size={15} strokeWidth={1.7} />{label}</span>{location === href && <span className="h-1.5 w-1.5 bg-[#b8ed64]" />}</Link>)}</nav>
      </div>
      <div className="mt-auto border-t border-[#202a35] p-5"><div className="mb-3 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.15em] text-[#637180]"><ShieldAlert size={13} />Desk protocol</div><p className="text-[11px] leading-5 text-[#697786]">Live market data is used where available. Missing metrics remain explicitly unavailable.</p><div className="mt-5 flex items-center gap-2 text-[10px] text-[#697786]"><span className="h-1.5 w-1.5 rounded-full bg-[#b8ed64]" />Session protected</div></div>
    </aside>
    {open && <button aria-label="Close navigation" data-testid="button-close-navigation" onClick={() => setOpen(false)} className="fixed inset-0 z-40 bg-[#05070a]/70 lg:hidden" />}
    <main className="min-h-[100dvh] lg:pl-[236px]">{children}</main>
  </div>;
}

function Topbar({ alpha = false, ai = false }: { alpha?: boolean; ai?: boolean }) {
  const [, setLocation] = useLocation();
  return <header className="sticky top-0 z-30 flex h-[76px] items-center justify-between border-b border-[#202a35] bg-[#0d1118]/95 px-5 backdrop-blur-md sm:px-8">
    <div className="flex items-center gap-3"><button className="rounded-sm p-2 text-[#8793a0] hover:bg-[#18212a] lg:hidden" aria-label="Open navigation" data-testid="button-open-navigation" onClick={() => document.dispatchEvent(new CustomEvent('grios:open-nav'))}><Menu size={19} /></button><div><div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.2em] text-[#677583]">GRIOS / <span className="text-[#adb7c0]">{alpha ? 'Alpha scanner' : ai ? 'Autonomous CIO' : 'Live terminal'}</span></div><h1 className="mt-1 font-mono text-[13px] tracking-[.08em] text-[#f1efe8] sm:text-[15px]">{alpha ? 'HIGH-GROWTH OPPORTUNITIES' : ai ? 'AUTONOMOUS CIO BRIEF' : 'MARKET INTELLIGENCE OVERVIEW'}</h1></div></div>
    <div className="flex items-center gap-2 sm:gap-4"><div className="hidden items-center gap-2 text-[10px] text-[#6c7985] sm:flex"><span className="h-1.5 w-1.5 animate-pulse rounded-full bg-[#b8ed64]" />LIVE RESEARCH MODE</div><button onClick={() => setLocation(alpha ? '/' : ai ? '/alpha' : '/ai')} data-testid="button-switch-view" className="flex items-center gap-2 border border-[#29343f] px-3 py-2 text-[10px] font-bold uppercase tracking-[.12em] text-[#9ca7b0] transition hover:border-[#b8ed64]/50 hover:text-[#d8efa9]"><SlidersHorizontal size={13} /> <span className="hidden sm:inline">{alpha ? 'Overview' : ai ? 'Full scanner' : 'CIO brief'}</span></button></div>
  </header>;
}

function ConnectionCard({ connection, loading, error, onRefresh }: { connection?: ConnectionStatus; loading: boolean; error?: boolean; onRefresh: () => void }) {
  return <section className="border border-[#26323e] bg-[#111820] p-5 shadow-[0_16px_50px_rgba(0,0,0,.16)] sm:p-6"><div className="flex items-start justify-between"><div><div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.18em] text-[#758391]"><Wifi size={13} className="text-[#b8ed64]" />Data connection</div><div className="mt-4 flex items-center gap-3">{loading ? <div className="skeleton h-7 w-24" /> : <StatusPill status={error ? 'error' : connection?.status} />}<span className="text-[11px] text-[#71808c]">{connection?.provider || 'CoinGecko'} / REST</span></div></div><button onClick={onRefresh} disabled={loading} data-testid="button-refresh-connection" className="rounded-sm border border-[#293640] p-2 text-[#7d8a96] transition hover:border-[#b8ed64]/50 hover:text-[#c8ef83] disabled:opacity-40" aria-label="Refresh connection"><RefreshCw size={14} className={loading ? 'animate-spin' : ''} /></button></div><p data-testid="status-connection-message" className="mt-5 border-t border-[#202b35] pt-4 text-[12px] leading-5 text-[#9da8b1]">{loading ? 'Checking provider handshake…' : error ? 'Unable to reach the connection endpoint. Retry when ready.' : connection?.message || 'Connection status unavailable.'}</p><div className="mt-4 flex items-center justify-between text-[10px] uppercase tracking-[.12em] text-[#5f6e7b]"><span>Checked {shortTime(connection?.checked_at)}</span><span className={connection?.api_key_configured ? 'text-[#b8ed64]' : 'text-[#e1ab50]'}>{connection?.api_key_configured ? 'Key configured' : 'Key not configured'}</span></div></section>;
}

function MetricCard({ label, value, detail, accent = 'lime', loading = false }: { label: string; value: string; detail: string; accent?: 'lime' | 'cyan' | 'amber'; loading?: boolean }) {
  const color = accent === 'cyan' ? 'text-[#6ed9e6]' : accent === 'amber' ? 'text-[#e1ab50]' : 'text-[#b8ed64]';
  return <div className="border border-[#26323e] bg-[#111820] p-5 sm:p-6"><div className="mb-5 flex items-center justify-between text-[10px] font-bold uppercase tracking-[.18em] text-[#758391]"><span>{label}</span><span className={`h-1.5 w-1.5 rounded-full bg-current ${color}`} /></div>{loading ? <div className="skeleton h-9 w-28" /> : <div data-testid={`text-metric-${label.toLowerCase().replaceAll(' ', '-')}`} className={`font-mono text-[26px] tracking-tight ${color}`}>{value}</div>}<div className="mt-2 text-[11px] text-[#71808c]">{detail}</div></div>;
}

function Methodology() {
  return <section className="border border-[#26323e] bg-[#111820] p-5 sm:p-6"><div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.18em] text-[#758391]"><Gauge size={14} className="text-[#6ed9e6]" />Scanner methodology</div><p className="mt-5 max-w-xl text-[13px] leading-6 text-[#adb7bf]">Ranks small- and mid-cap projects against live market structure. The signal combines momentum, liquidity and valuation context—then exposes the data gaps before a CIO decision.</p><div className="mt-6 grid grid-cols-2 gap-x-5 gap-y-4 border-t border-[#202b35] pt-5 sm:grid-cols-4"><div><div className="mono text-[17px] text-[#f0eee7]">01</div><div className="mt-1 text-[10px] uppercase tracking-[.11em] text-[#6f7e8b]">Universe</div></div><div><div className="mono text-[17px] text-[#f0eee7]">02</div><div className="mt-1 text-[10px] uppercase tracking-[.11em] text-[#6f7e8b]">Momentum</div></div><div><div className="mono text-[17px] text-[#f0eee7]">03</div><div className="mt-1 text-[10px] uppercase tracking-[.11em] text-[#6f7e8b]">Liquidity</div></div><div><div className="mono text-[17px] text-[#f0eee7]">04</div><div className="mt-1 text-[10px] uppercase tracking-[.11em] text-[#6f7e8b]">Risk gate</div></div></div></section>;
}

function OpportunityRow({ item }: { item: AlphaOpportunity }) {
  const up = (item.change_24h ?? 0) >= 0;
  const decision = item.cio_decision?.toLowerCase() || '';
  return <div data-testid={`row-opportunity-${item.coin_id}`} className="group grid min-w-[920px] grid-cols-[42px_1.7fr_1fr_1fr_1fr_1fr_1fr_112px] items-center gap-3 border-b border-[#202b35] px-4 py-4 text-[12px] transition-colors hover:bg-[#17212a] sm:px-5">
    <span className="mono text-[11px] text-[#697784]">#{String(item.rank).padStart(2, '0')}</span>
    <div className="flex min-w-0 items-center gap-3"><div className="flex h-8 w-8 shrink-0 items-center justify-center overflow-hidden rounded-full border border-[#30404a] bg-[#19232c] text-[10px] font-bold text-[#b8ed64]">{item.image ? <img src={item.image} alt="" className="h-full w-full object-cover" /> : item.ticker.slice(0, 2)}</div><div className="min-w-0"><div className="truncate font-semibold text-[#e8e6df]">{item.project}</div><div className="mono mt-0.5 text-[10px] uppercase text-[#697886]">{item.ticker}</div></div></div>
    <div><div className="mono text-[#d9d8d1]">{formatMoney(item.market_cap)}</div><div className="mt-1 text-[10px] text-[#667581]">MKT CAP</div></div>
    <div><div className="mono text-[#d9d8d1]">{formatMoney(item.volume)}</div><div className="mt-1 text-[10px] text-[#667581]">VOLUME</div></div>
    <div><div className={`mono flex items-center gap-1 ${up ? 'text-[#b8ed64]' : 'text-[#ed817a]'}`}>{up ? <ArrowUpRight size={13} /> : <ArrowDownRight size={13} />}{formatPct(item.change_24h)}</div><div className="mt-1 text-[10px] text-[#667581]">24H MOVE</div></div>
    <div><div className="mono text-[#d9d8d1]">{item.alpha_score === null ? '—' : item.alpha_score.toFixed(1)}</div><div className="mt-1 text-[10px] text-[#667581]">ALPHA SCORE</div></div>
    <div><div className="max-w-[130px] truncate text-[#bfc9cf]">{item.catalyst_signal || '—'}</div><div className="mt-1 text-[10px] text-[#667581]">CATALYST</div></div>
    <div className={`justify-self-end rounded-sm border px-2 py-1 text-center text-[9px] font-bold uppercase tracking-[.11em] ${decision.includes('buy') || decision.includes('accumulate') ? 'border-[#b8ed64]/30 bg-[#b8ed64]/10 text-[#b8ed64]' : decision.includes('avoid') || decision.includes('sell') ? 'border-[#ed817a]/30 bg-[#ed817a]/10 text-[#ed817a]' : 'border-[#e1ab50]/30 bg-[#e1ab50]/10 text-[#e1ab50]'}`}>{item.cio_decision || 'Review'}</div>
  </div>;
}

function OpportunityTable({ items, loading, error }: { items: AlphaOpportunity[]; loading: boolean; error?: string | null }) {
  return <section className="border border-[#26323e] bg-[#111820]"><div className="flex flex-wrap items-center justify-between gap-4 border-b border-[#26323e] px-5 py-5 sm:px-6"><div><div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.18em] text-[#758391]"><Sparkles size={14} className="text-[#b8ed64]" />Ranked alpha opportunities</div><p className="mt-2 text-[12px] text-[#6f7d89]">Live small- and mid-cap scan / highest conviction first</p></div><Link href="/alpha" data-testid="link-view-full-scanner" className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-[.12em] text-[#b8ed64] hover:text-[#e4f8be]">Open full scanner <ChevronRight size={13} /></Link></div><div className="scrollbar-thin overflow-x-auto">{loading ? <div className="space-y-3 p-5">{[1, 2, 3, 4].map(x => <div key={x} className="skeleton h-12 w-full" />)}</div> : error ? <div className="flex min-h-[220px] flex-col items-center justify-center p-8 text-center"><AlertTriangle className="mb-3 text-[#e1ab50]" size={22} /><p className="text-[13px] text-[#c4cacf]">Alpha scan unavailable</p><p className="mt-1 text-[11px] text-[#6f7d89]">{error}</p></div> : items.length === 0 ? <div className="flex min-h-[220px] flex-col items-center justify-center p-8 text-center"><Search className="mb-3 text-[#677583]" size={22} /><p className="text-[13px] text-[#c4cacf]">No opportunities returned</p><p className="mt-1 text-[11px] text-[#6f7d89]">The scanner has no eligible assets in this window.</p></div> : <><div className="grid min-w-[920px] grid-cols-[42px_1.7fr_1fr_1fr_1fr_1fr_1fr_112px] gap-3 border-b border-[#202b35] bg-[#0e151c] px-4 py-3 text-[9px] font-bold uppercase tracking-[.16em] text-[#5f6e7b] sm:px-5"><span>#</span><span>Project</span><span>Market cap</span><span>Volume</span><span>24h</span><span>Score</span><span>Signal</span><span className="text-right">Decision</span></div>{items.map(item => <OpportunityRow key={item.coin_id} item={item} />)}</>}</div></section>;
}

function Overview() {
  const connection = useGetConnectionStatus({ query: { queryKey: getGetConnectionStatusQueryKey(), refetchInterval: 30000, staleTime: 15000 } });
  const health = useHealthCheck({ query: { queryKey: getHealthCheckQueryKey(), refetchInterval: 30000, staleTime: 15000 } });
  const alpha = useGetCryptoAlpha({ limit: 8, include_majors: false }, { query: { queryKey: getGetCryptoAlphaQueryKey({ limit: 8, include_majors: false }), refetchInterval: 60000, staleTime: 30000 } });
  const scan = alpha.data;
  const scanned = scan?.scanned_size ?? 0;
  const universe = scan?.universe_size ?? 0;
  return <><Topbar /><div className="terminal-grid min-h-[calc(100dvh-76px)] px-5 py-7 sm:px-8 sm:py-10"><div className="mx-auto max-w-[1440px]"><div className="mb-8 flex flex-col justify-between gap-5 xl:flex-row xl:items-end"><div className="animate-rise"><div className="mb-3 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.22em] text-[#768592]"><span className="h-1.5 w-1.5 bg-[#b8ed64]" />Desk overview / 06:42 UTC</div><h2 className="max-w-2xl text-[28px] font-extrabold leading-[1.08] tracking-[-.04em] text-[#f0eee7] sm:text-[42px]">Signal before <span className="text-[#b8ed64]">narrative.</span></h2><p className="mt-4 max-w-xl text-[13px] leading-6 text-[#8896a2]">A live read on the connection, the universe, and the few opportunities worth putting in front of the investment committee.</p></div><div className="animate-rise stagger-1 flex items-center gap-3 border-l border-[#b8ed64]/40 pl-4 text-[10px] uppercase tracking-[.13em] text-[#83919c]"><Activity size={15} className="text-[#b8ed64]" /><span>Last scan<br /><strong className="mono mt-1 inline-block text-[#d9e3cc]">{shortTime(scan?.generated_at)}</strong></span></div></div>
      <div className="grid gap-4 lg:grid-cols-[1.05fr_1fr_1fr]"><div className="animate-rise"><ConnectionCard connection={connection.data} loading={connection.isLoading} error={!!connection.error} onRefresh={() => connection.refetch()} /></div><div className="animate-rise stagger-1"><MetricCard label="Market universe" value={universe ? universe.toLocaleString() : '—'} detail={`${scanned.toLocaleString()} assets evaluated in scan`} accent="cyan" loading={alpha.isLoading} /></div><div className="animate-rise stagger-2"><MetricCard label="Scan health" value={health.isError ? 'DEGRADED' : health.data?.status?.toUpperCase() || '—'} detail={scan?.excluded_majors ? 'BTC / ETH excluded by policy' : 'Major assets included'} accent={health.isError ? 'amber' : 'lime'} loading={health.isLoading} /></div></div>
      <div className="mt-4 grid gap-4 xl:grid-cols-[1fr_1.65fr]"><Methodology /><div className="border border-[#26323e] bg-[#111820] p-5 sm:p-6"><div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.18em] text-[#758391]"><Database size={14} className="text-[#e1ab50]" />Coverage notes</div><div className="mt-5 grid gap-4 sm:grid-cols-3"><div><div className="mono text-[20px] text-[#e1ab50]">{scan?.unavailable_data?.length || 0}</div><div className="mt-1 text-[10px] uppercase tracking-[.11em] text-[#6f7d89]">Unavailable fields</div></div><div><div className="mono text-[20px] text-[#6ed9e6]">{scan?.excluded_majors ? 'YES' : 'NO'}</div><div className="mt-1 text-[10px] uppercase tracking-[.11em] text-[#6f7d89]">Major exclusion</div></div><div><div className="mono text-[20px] text-[#b8ed64]">{scan?.opportunities?.length || 0}</div><div className="mt-1 text-[10px] uppercase tracking-[.11em] text-[#6f7d89]">Ranked signals</div></div></div><div className="mt-5 border-t border-[#202b35] pt-4 text-[11px] leading-5 text-[#71808c]">{scan?.unavailable_data?.length ? `Metrics withheld by provider: ${scan.unavailable_data.join(', ')}.` : 'All requested fields returned by the provider for this scan.'}</div></div></div>
      <div className="mt-4 animate-rise stagger-3"><OpportunityTable items={scan?.opportunities || []} loading={alpha.isLoading} error={scan?.error || (alpha.error ? 'The provider did not return a valid scan.' : null)} /></div>
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3 border-t border-[#202a35] pt-4 text-[10px] uppercase tracking-[.12em] text-[#5e6d79]"><span className="flex items-center gap-2"><Server size={12} /> Health endpoint: <span className={health.data ? 'text-[#b8ed64]' : 'text-[#e1ab50]'}>{health.data?.status || 'pending'}</span></span><span>GRIOS / Internal research tooling / v0.1</span></div>
    </div></div></>;
}

function AlphaPage() {
  const [limit, setLimit] = useState(20);
  const alpha = useGetCryptoAlpha({ limit, include_majors: false }, { query: { queryKey: getGetCryptoAlphaQueryKey({ limit, include_majors: false }), refetchInterval: 60000, staleTime: 30000 } });
  const items = useMemo(() => alpha.data?.opportunities || [], [alpha.data?.opportunities]);
  return <><Topbar alpha /><div className="terminal-grid min-h-[calc(100dvh-76px)] px-5 py-7 sm:px-8 sm:py-10"><div className="mx-auto max-w-[1500px]"><div className="mb-8 flex flex-col justify-between gap-5 md:flex-row md:items-end"><div><div className="mb-3 text-[10px] font-bold uppercase tracking-[.22em] text-[#768592]">Research surface / ranked output</div><h2 className="text-[28px] font-extrabold leading-none tracking-[-.04em] text-[#f0eee7] sm:text-[38px]">Alpha scanner</h2><p className="mt-4 max-w-2xl text-[13px] leading-6 text-[#8896a2]">The opportunity set, expanded. Every row is ranked against the same live inputs, with unavailable metrics kept visible rather than inferred.</p></div><div className="flex items-center gap-2"><button onClick={() => setLimit(8)} data-testid="button-limit-8" className={`border px-3 py-2 text-[10px] font-bold uppercase tracking-[.12em] ${limit === 8 ? 'border-[#b8ed64]/40 bg-[#b8ed64]/10 text-[#b8ed64]' : 'border-[#293640] text-[#7d8b96]'}`}>Top 8</button><button onClick={() => setLimit(20)} data-testid="button-limit-20" className={`border px-3 py-2 text-[10px] font-bold uppercase tracking-[.12em] ${limit === 20 ? 'border-[#b8ed64]/40 bg-[#b8ed64]/10 text-[#b8ed64]' : 'border-[#293640] text-[#7d8b96]'}`}>Top 20</button><button onClick={() => alpha.refetch()} data-testid="button-refresh-alpha" className="border border-[#293640] p-2 text-[#7d8b96] hover:border-[#b8ed64]/40 hover:text-[#b8ed64]" aria-label="Refresh alpha scan"><RefreshCw size={14} className={alpha.isFetching ? 'animate-spin' : ''} /></button></div></div><OpportunityTable items={items} loading={alpha.isLoading} error={alpha.data?.error || (alpha.error ? 'Provider connection unavailable.' : null)} /><div className="mt-4 grid gap-4 md:grid-cols-3"><div className="border border-[#26323e] bg-[#111820] p-5"><div className="text-[10px] font-bold uppercase tracking-[.16em] text-[#697886]">Generated</div><div className="mono mt-3 text-[14px] text-[#d9e4d0]">{shortTime(alpha.data?.generated_at)}</div></div><div className="border border-[#26323e] bg-[#111820] p-5"><div className="text-[10px] font-bold uppercase tracking-[.16em] text-[#697886]">Universe coverage</div><div className="mono mt-3 text-[14px] text-[#6ed9e6]">{alpha.data?.scanned_size || 0} / {alpha.data?.universe_size || 0}</div></div><div className="border border-[#26323e] bg-[#111820] p-5"><div className="text-[10px] font-bold uppercase tracking-[.16em] text-[#697886]">Provider status</div><div className="mt-3"><StatusPill status={alpha.data?.connection.status} /></div></div></div></div></div></>;
}

function AiRoute() { return <><Topbar ai /><AiPage /></>; }
function Router() { return <ErrorBoundary resetKey={useLocation()[0]}><Switch><Route path="/" component={Overview} /><Route path="/alpha" component={AlphaPage} /><Route path="/ai" component={AiRoute} /><Route component={NotFound} /></Switch></ErrorBoundary>; }
function App() { return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Shell><Router /></Shell></WouterRouter><Toaster /></TooltipProvider></QueryClientProvider>; }
export default App;