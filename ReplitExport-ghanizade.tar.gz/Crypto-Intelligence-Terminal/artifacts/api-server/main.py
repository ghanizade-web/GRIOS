from __future__ import annotations

import os
from statistics import mean
from datetime import datetime, timezone
from typing import Any

import httpx
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field


API_PREFIX = "/api"
COINGECKO_BASE_URL = "https://api.coingecko.com/api/v3"
MAJOR_IDS = {"bitcoin", "ethereum"}


class ConnectionStatus(BaseModel):
    provider: str = "CoinGecko"
    status: str
    message: str
    checked_at: str
    api_key_configured: bool


class AlphaOpportunity(BaseModel):
    rank: int
    project: str
    ticker: str
    coin_id: str
    image: str | None = None
    market_cap: float | None = None
    volume: float | None = None
    momentum: float | None = None
    change_24h: float | None = None
    change_7d: float | None = None
    change_30d: float | None = None
    liquidity: float | None = None
    fdv: float | None = None
    catalyst_signal: str
    risk: str
    alpha_score: float | None = None
    cio_decision: str
    data_status: str
    available_metrics: list[str] = Field(default_factory=list)
    unavailable_metrics: list[str] = Field(default_factory=list)


class AlphaScanResponse(BaseModel):
    generated_at: str
    universe_size: int
    scanned_size: int
    excluded_majors: bool
    connection: ConnectionStatus
    opportunities: list[AlphaOpportunity] = Field(default_factory=list)
    unavailable_data: list[str] = Field(default_factory=list)
    error: str | None = None


class AIEvidence(BaseModel):
    status: str
    detail: str


class AIBtcState(BaseModel):
    status: str
    current_price: float | None = None
    change_24h: float | None = None
    change_7d: float | None = None
    change_30d: float | None = None
    trend: str
    data_status: str


class AIMarketRegime(BaseModel):
    regime: str
    risk_level: str
    summary: str
    btc: AIBtcState
    evidence: list[AIEvidence] = Field(default_factory=list)


class AITimeframeContext(BaseModel):
    timeframe: str
    state: str
    change: float | None = None
    detail: str
    data_status: str


class AITradePlan(BaseModel):
    market_state: str
    btc_state: str
    multi_timeframe: list[AITimeframeContext] = Field(default_factory=list)
    volume_liquidity: str
    capital_flow_smart_money: str
    technical_setup: str
    current_price: float | None = None
    entry_zone_low: float | None = None
    entry_zone_high: float | None = None
    stop: float | None = None
    targets: list[float] = Field(default_factory=list)
    risk_reward: float | None = None
    confidence: float | None = None
    cio_decision: str
    data_status: str
    unavailable_evidence: list[str] = Field(default_factory=list)


class AIOpportunity(BaseModel):
    rank: int
    asset: str
    ticker: str
    coin_id: str
    theme: str
    score: float | None = None
    reason: str
    risk: str
    time_horizon: str
    trade_candidate: bool
    data_status: str
    evidence: list[AIEvidence] = Field(default_factory=list)
    trade_plan: AITradePlan


class AIBriefResponse(BaseModel):
    generated_at: str
    mode: str
    llm_status: str
    data_status: str
    universe_size: int
    scanned_size: int
    excluded_majors: bool
    connection: ConnectionStatus
    market: AIMarketRegime
    major_risks: list[AIEvidence] = Field(default_factory=list)
    opportunities: list[AIOpportunity] = Field(default_factory=list)
    unavailable_data: list[str] = Field(default_factory=list)
    error: str | None = None


app = FastAPI(
    title="GRIOS Crypto Intelligence Terminal",
    version="1.0.0",
    docs_url=f"{API_PREFIX}/docs",
    redoc_url=f"{API_PREFIX}/redoc",
)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=False,
    allow_methods=["GET"],
    allow_headers=["*"],
)


def now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def has_key() -> bool:
    return bool(os.getenv("COINGECKO_API_KEY", "").strip())


def status(
    state: str,
    message: str,
    *,
    checked_at: str | None = None,
) -> ConnectionStatus:
    return ConnectionStatus(
        status=state,
        message=message,
        checked_at=checked_at or now_iso(),
        api_key_configured=has_key(),
    )


def coingecko_headers() -> dict[str, str]:
    key = os.getenv("COINGECKO_API_KEY", "").strip()
    if not key:
        return {}
    # CoinGecko Demo keys are accepted through this header. Keeping the
    # provider-specific header in one function makes a future Pro connector
    # easy to add without leaking provider details into route handlers.
    return {"x-cg-demo-api-key": key}


async def fetch_market_universe() -> list[dict[str, Any]]:
    params = {
        "vs_currency": "usd",
        "order": "market_cap_desc",
        "per_page": "250",
        "page": "1",
        "sparkline": "false",
        "price_change_percentage": "24h,7d,30d",
        "locale": "en",
    }
    async with httpx.AsyncClient(
        base_url=COINGECKO_BASE_URL,
        headers={"accept": "application/json", **coingecko_headers()},
        timeout=httpx.Timeout(20.0, connect=8.0),
    ) as client:
        response = await client.get("/coins/markets", params=params)
        response.raise_for_status()
        payload = response.json()
        if not isinstance(payload, list):
            raise ValueError("CoinGecko returned an unexpected market universe shape.")
        return payload


def number_or_none(value: Any) -> float | None:
    return float(value) if isinstance(value, (int, float)) else None


def metric_score(value: float | None, low: float, high: float) -> float | None:
    if value is None:
        return None
    clipped = max(low, min(high, value))
    return ((clipped - low) / (high - low)) * 100


def rank_opportunity(coin: dict[str, Any]) -> AlphaOpportunity:
    market_cap = number_or_none(coin.get("market_cap"))
    volume = number_or_none(coin.get("total_volume"))
    change_24h = number_or_none(coin.get("price_change_percentage_24h"))
    change_7d = number_or_none(coin.get("price_change_percentage_7d_in_currency"))
    change_30d = number_or_none(coin.get("price_change_percentage_30d_in_currency"))
    fdv = number_or_none(coin.get("fully_diluted_valuation"))
    market_cap_rank = number_or_none(coin.get("market_cap_rank"))
    liquidity = (volume / market_cap * 100) if volume and market_cap else None

    available: list[str] = []
    unavailable: list[str] = []
    for label, value in (
        ("market cap", market_cap),
        ("volume", volume),
        ("24h change", change_24h),
        ("7d performance", change_7d),
        ("30d performance", change_30d),
        ("liquidity", liquidity),
        ("FDV", fdv),
    ):
        (available if value is not None else unavailable).append(label)

    components: list[float] = []
    for value, low, high in (
        (change_24h, -15, 25),
        (change_7d, -30, 80),
        (change_30d, -50, 180),
        (liquidity, 0.2, 30),
    ):
        score = metric_score(value, low, high)
        if score is not None:
            components.append(score)

    if market_cap is not None:
        # Give smaller/mid-cap assets a measured preference without rewarding
        # assets that fall below the universe's usable liquidity floor.
        components.append(float(metric_score(market_cap, 50_000_000, 10_000_000_000) or 0))

    alpha_score = round(sum(components) / len(components), 1) if components else None
    momentum_values = [value for value in (change_24h, change_7d, change_30d) if value is not None]
    momentum = round(sum(momentum_values) / len(momentum_values), 1) if momentum_values else None

    if alpha_score is None:
        catalyst = "Insufficient live metrics"
        decision = "WATCH — DATA GAP"
    elif momentum is not None and momentum >= 35 and (liquidity or 0) >= 2:
        catalyst = "Broad-based momentum with tradable volume"
        decision = "PRIORITIZE — VERIFY CATALYST"
    elif momentum is not None and momentum >= 12:
        catalyst = "Positive trend; continuation signal"
        decision = "ACCUMULATE — SIZE TO RISK"
    elif (liquidity or 0) >= 5:
        catalyst = "Liquidity support, momentum not confirmed"
        decision = "WATCH — NEEDS FOLLOW-THROUGH"
    else:
        catalyst = "No strong live catalyst signal"
        decision = "PASS — SIGNAL WEAK"

    if market_cap_rank and market_cap_rank > 150:
        risk = "HIGH — smaller-cap volatility"
    elif (liquidity or 0) < 1:
        risk = "HIGH — thin relative volume"
    elif fdv and market_cap and fdv > market_cap * 3:
        risk = "HIGH — FDV overhang"
    elif unavailable:
        risk = "ELEVATED — partial data"
    else:
        risk = "MEDIUM — market beta"

    return AlphaOpportunity(
        rank=0,
        project=str(coin.get("name") or coin.get("id") or "Unknown"),
        ticker=str(coin.get("symbol") or "—").upper(),
        coin_id=str(coin.get("id") or ""),
        image=coin.get("image") if isinstance(coin.get("image"), str) else None,
        market_cap=market_cap,
        volume=volume,
        momentum=momentum,
        change_24h=change_24h,
        change_7d=change_7d,
        change_30d=change_30d,
        liquidity=round(liquidity, 2) if liquidity is not None else None,
        fdv=fdv,
        catalyst_signal=catalyst,
        risk=risk,
        alpha_score=alpha_score,
        cio_decision=decision,
        data_status="LIVE" if not unavailable else "LIVE / PARTIAL",
        available_metrics=available,
        unavailable_metrics=unavailable,
    )


def error_scan(connection: ConnectionStatus, message: str) -> AlphaScanResponse:
    return AlphaScanResponse(
        generated_at=now_iso(),
        universe_size=0,
        scanned_size=0,
        excluded_majors=True,
        connection=connection,
        opportunities=[],
        unavailable_data=["market universe", "ranked opportunities"],
        error=message,
    )


def eligible_coins(universe: list[dict[str, Any]], include_majors: bool = False) -> list[dict[str, Any]]:
    filtered = [
        coin
        for coin in universe
        if include_majors or str(coin.get("id", "")).lower() not in MAJOR_IDS
    ]
    return [
        coin
        for coin in filtered
        if coin.get("market_cap") is None
        or 50_000_000 <= float(coin.get("market_cap") or 0) <= 10_000_000_000
    ]


def change_text(value: float | None) -> str:
    return "unavailable" if value is None else f"{value:+.1f}%"


def money_text(value: float | None) -> str:
    if value is None:
        return "unavailable"
    if value >= 1_000_000_000:
        return f"${value / 1_000_000_000:.2f}B"
    if value >= 1_000_000:
        return f"${value / 1_000_000:.1f}M"
    if value >= 1_000:
        return f"${value / 1_000:.1f}K"
    return f"${value:.2f}"


def build_market_regime(universe: list[dict[str, Any]]) -> tuple[AIMarketRegime, list[AIEvidence]]:
    btc = next((coin for coin in universe if coin.get("id") == "bitcoin"), None)
    btc_24h = number_or_none(btc.get("price_change_percentage_24h")) if btc else None
    btc_7d = number_or_none(btc.get("price_change_percentage_7d_in_currency")) if btc else None
    btc_30d = number_or_none(btc.get("price_change_percentage_30d_in_currency")) if btc else None
    btc_price = number_or_none(btc.get("current_price")) if btc else None
    non_major = [coin for coin in universe if str(coin.get("id", "")).lower() not in MAJOR_IDS]
    changes_7d = [
        value
        for value in (number_or_none(coin.get("price_change_percentage_7d_in_currency")) for coin in non_major)
        if value is not None
    ]
    positive_7d = [value for value in changes_7d if value > 0]
    breadth = len(positive_7d) / len(changes_7d) if changes_7d else None
    average_7d = mean(changes_7d) if changes_7d else None

    if btc_7d is not None and breadth is not None and average_7d is not None:
        if btc_7d >= 5 and breadth >= 0.55 and average_7d >= 3:
            regime = "RISK-ON / MOMENTUM"
            risk_level = "ELEVATED"
            summary = "BTC and broad market breadth are positive; momentum setups are favored, but small/mid-cap volatility remains elevated."
        elif btc_7d <= -5 and breadth <= 0.45 and average_7d <= -3:
            regime = "RISK-OFF / DEFENSIVE"
            risk_level = "HIGH"
            summary = "BTC and market breadth are weak; preserve capital and require confirmation before taking risk."
        else:
            regime = "MIXED / SELECTIVE"
            risk_level = "HIGH"
            summary = "Cross-asset signals are mixed; only selective, liquid setups with defined risk qualify."
    else:
        regime = "UNKNOWN / DATA GAP"
        risk_level = "UNKNOWN"
        summary = "The live feed does not contain enough breadth and BTC timeframe metrics to classify the regime."

    if btc_7d is not None and btc_30d is not None:
        btc_trend = "BULLISH" if btc_7d > 0 and btc_30d > 0 else "BEARISH" if btc_7d < 0 and btc_30d < 0 else "MIXED"
        btc_status = "LIVE"
    else:
        btc_trend = "UNAVAILABLE"
        btc_status = "UNAVAILABLE"
    evidence = [
        AIEvidence(
            status="LIVE" if btc_7d is not None else "UNAVAILABLE",
            detail=f"BTC: 24h {change_text(btc_24h)} / 7d {change_text(btc_7d)} / 30d {change_text(btc_30d)}.",
        ),
        AIEvidence(
            status="DERIVED" if breadth is not None else "UNAVAILABLE",
            detail=f"Non-major 7d breadth: {breadth:.0%} positive across {len(changes_7d)} assets."
            if breadth is not None
            else "Non-major 7d breadth is unavailable.",
        ),
    ]
    return (
        AIMarketRegime(
            regime=regime,
            risk_level=risk_level,
            summary=summary,
            btc=AIBtcState(
                status="LIVE" if btc else "UNAVAILABLE",
                current_price=btc_price,
                change_24h=btc_24h,
                change_7d=btc_7d,
                change_30d=btc_30d,
                trend=btc_trend,
                data_status=btc_status,
            ),
            evidence=evidence,
        ),
        evidence,
    )


def timeframe_context(coin: dict[str, Any], timeframe: str, key: str) -> AITimeframeContext:
    value = number_or_none(coin.get(key))
    if value is None:
        return AITimeframeContext(
            timeframe=timeframe,
            state="UNAVAILABLE",
            change=None,
            detail=f"{timeframe} change is not present in the live provider response.",
            data_status="UNAVAILABLE",
        )
    state = "BULLISH" if value > 0 else "BEARISH" if value < 0 else "FLAT"
    return AITimeframeContext(
        timeframe=timeframe,
        state=state,
        change=value,
        detail=f"LIVE {timeframe} change: {change_text(value)}.",
        data_status="LIVE",
    )


def build_trade_plan(
    coin: dict[str, Any],
    alpha: AlphaOpportunity,
    market: AIMarketRegime,
) -> AITradePlan:
    current_price = number_or_none(coin.get("current_price"))
    required_values = [
        current_price,
        alpha.change_24h,
        alpha.change_7d,
        alpha.change_30d,
        alpha.volume,
        alpha.market_cap,
        alpha.liquidity,
    ]
    missing = [
        label
        for label, value in zip(
            ["current price", "24h change", "7d performance", "30d performance", "volume", "market cap", "liquidity"],
            required_values,
        )
        if value is None
    ]
    timeframes = [
        timeframe_context(coin, "24H", "price_change_percentage_24h"),
        timeframe_context(coin, "7D", "price_change_percentage_7d_in_currency"),
        timeframe_context(coin, "30D", "price_change_percentage_30d_in_currency"),
    ]
    aligned = (
        not missing
        and alpha.change_7d is not None
        and alpha.change_30d is not None
        and alpha.momentum is not None
        and alpha.change_7d > 0
        and alpha.change_30d > 0
        and alpha.momentum >= 12
        and (alpha.liquidity or 0) >= 1
    )
    volume_liquidity = (
        f"LIVE volume {money_text(alpha.volume)}; volume/market cap liquidity {alpha.liquidity:.2f}%."
        if alpha.volume is not None and alpha.liquidity is not None
        else "UNAVAILABLE — live volume/liquidity metrics are incomplete."
    )
    capital_flow = "UNAVAILABLE — CoinGecko market data does not expose wallet-flow or smart-money positioning."
    if aligned and current_price is not None:
        entry_low = round(current_price * 0.98, 12)
        entry_high = round(current_price * 1.01, 12)
        entry_mid = (entry_low + entry_high) / 2
        stop = round(current_price * 0.92, 12)
        targets = [round(current_price * 1.18, 12), round(current_price * 1.30, 12)]
        risk_reward = round((targets[0] - entry_mid) / (entry_mid - stop), 2)
        confidence = 62 + min(18, max(0, abs(alpha.momentum or 0) / 4)) + (8 if (alpha.liquidity or 0) >= 5 else 0)
        if "HIGH" in alpha.risk:
            confidence -= 8
        confidence = round(min(90, confidence), 1)
        decision = "ACTIONABLE — SIZE TO RISK" if risk_reward >= 2 else "WAIT — RR BELOW 1:2"
        technical = "LIVE aligned momentum across 7D/30D; 24H confirms continuation. Entry is a model-derived pullback/continuation zone."
    else:
        entry_low = entry_high = stop = None
        targets = []
        risk_reward = None
        confidence = None
        decision = "WAIT — DATA GAP" if missing else "WAIT — TREND NOT ALIGNED"
        technical = (
            "UNAVAILABLE — insufficient live price/timeframe/liquidity metrics for a defined trade plan."
            if missing
            else "LIVE mixed or insufficient trend alignment; no actionable setup."
        )
    unavailable = list(missing)
    unavailable.append("capital-flow / smart-money evidence")
    return AITradePlan(
        market_state=market.regime,
        btc_state=f"LIVE BTC trend {market.btc.trend}; 7D {change_text(market.btc.change_7d)} / 30D {change_text(market.btc.change_30d)}.",
        multi_timeframe=timeframes,
        volume_liquidity=volume_liquidity,
        capital_flow_smart_money=capital_flow,
        technical_setup=technical,
        current_price=current_price,
        entry_zone_low=entry_low,
        entry_zone_high=entry_high,
        stop=stop,
        targets=targets,
        risk_reward=risk_reward,
        confidence=confidence,
        cio_decision=decision,
        data_status="LIVE / DERIVED" if not missing else "LIVE / PARTIAL",
        unavailable_evidence=unavailable,
    )


def empty_ai(connection: ConnectionStatus, message: str) -> AIBriefResponse:
    unavailable_market = AIMarketRegime(
        regime="UNKNOWN / DATA GAP",
        risk_level="UNKNOWN",
        summary="No live market synthesis was produced because the provider did not return a usable universe.",
        btc=AIBtcState(status="UNAVAILABLE", trend="UNAVAILABLE", data_status="UNAVAILABLE"),
        evidence=[AIEvidence(status="UNAVAILABLE", detail=message)],
    )
    return AIBriefResponse(
        generated_at=now_iso(),
        mode="DETERMINISTIC_EVIDENCE",
        llm_status="not_configured",
        data_status="UNAVAILABLE",
        universe_size=0,
        scanned_size=0,
        excluded_majors=True,
        connection=connection,
        market=unavailable_market,
        major_risks=[AIEvidence(status="UNAVAILABLE", detail=message)],
        opportunities=[],
        unavailable_data=["market universe", "Alpha Engine output", "trade evidence"],
        error=message,
    )


@app.get(API_PREFIX)
@app.get(f"{API_PREFIX}/health")
@app.get(f"{API_PREFIX}/healthz")
async def healthz() -> dict[str, str]:
    return {"status": "ok"}


@app.get(f"{API_PREFIX}/status", response_model=ConnectionStatus)
async def connection_status() -> ConnectionStatus:
    checked_at = now_iso()
    if not has_key():
        return status("unavailable", "COINGECKO_API_KEY is not configured.", checked_at=checked_at)
    try:
        await fetch_market_universe()
        return status("live", "CoinGecko market data is reachable.", checked_at=checked_at)
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 429:
            return status("rate_limited", "CoinGecko rate limit reached. Retry shortly.", checked_at=checked_at)
        return status("error", f"CoinGecko returned HTTP {exc.response.status_code}.", checked_at=checked_at)
    except Exception:
        return status("error", "CoinGecko could not be reached. No market data was substituted.", checked_at=checked_at)


@app.get(f"{API_PREFIX}/alpha/crypto", response_model=AlphaScanResponse)
async def crypto_alpha(
    limit: int = Query(20, ge=5, le=50),
    include_majors: bool = Query(False),
) -> AlphaScanResponse:
    checked_at = now_iso()
    if not has_key():
        connection = status("unavailable", "COINGECKO_API_KEY is not configured.", checked_at=checked_at)
        return error_scan(connection, "Live CoinGecko data is unavailable until COINGECKO_API_KEY is configured.")

    try:
        universe = await fetch_market_universe()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 429:
            connection = status("rate_limited", "CoinGecko rate limit reached. Retry shortly.", checked_at=checked_at)
            return error_scan(connection, "CoinGecko rate limited this scan. No cached or sample data was used.")
        connection = status("error", f"CoinGecko returned HTTP {exc.response.status_code}.", checked_at=checked_at)
        return error_scan(connection, "CoinGecko returned an error. No cached or sample data was used.")
    except Exception:
        connection = status("error", "CoinGecko could not be reached.", checked_at=checked_at)
        return error_scan(connection, "CoinGecko could not be reached. No cached or sample data was used.")

    candidates = eligible_coins(universe, include_majors)
    opportunities = [rank_opportunity(coin) for coin in candidates]
    opportunities.sort(key=lambda item: item.alpha_score if item.alpha_score is not None else -1, reverse=True)
    for rank, opportunity in enumerate(opportunities[:limit], start=1):
        opportunity.rank = rank

    unavailable = sorted(
        {
            metric
            for opportunity in opportunities[:limit]
            for metric in opportunity.unavailable_metrics
        }
    )
    return AlphaScanResponse(
        generated_at=now_iso(),
        universe_size=len(universe),
        scanned_size=len(candidates),
        excluded_majors=not include_majors,
        connection=status("live", "CoinGecko market data is live.", checked_at=checked_at),
        opportunities=opportunities[:limit],
        unavailable_data=unavailable,
        error=None,
    )


@app.get(f"{API_PREFIX}/ai", response_model=AIBriefResponse)
async def ai_brief(limit: int = Query(5, ge=3, le=8)) -> AIBriefResponse:
    checked_at = now_iso()
    if not has_key():
        connection = status("unavailable", "COINGECKO_API_KEY is not configured.", checked_at=checked_at)
        return empty_ai(connection, "Live CoinGecko data is unavailable until COINGECKO_API_KEY is configured.")
    try:
        universe = await fetch_market_universe()
    except httpx.HTTPStatusError as exc:
        if exc.response.status_code == 429:
            connection = status("rate_limited", "CoinGecko rate limit reached. Retry shortly.", checked_at=checked_at)
            return empty_ai(connection, "CoinGecko rate limited this synthesis. No cached or sample data was used.")
        connection = status("error", f"CoinGecko returned HTTP {exc.response.status_code}.", checked_at=checked_at)
        return empty_ai(connection, "CoinGecko returned an error. No cached or sample data was used.")
    except Exception:
        connection = status("error", "CoinGecko could not be reached.", checked_at=checked_at)
        return empty_ai(connection, "CoinGecko could not be reached. No cached or sample data was used.")

    candidates = eligible_coins(universe, include_majors=False)
    ranked = [rank_opportunity(coin) for coin in candidates]
    ranked.sort(key=lambda item: item.alpha_score if item.alpha_score is not None else -1, reverse=True)
    selected = ranked[:limit]
    raw_by_id = {str(coin.get("id")): coin for coin in candidates}
    market, market_evidence = build_market_regime(universe)
    major_risks: list[AIEvidence] = [
        AIEvidence(
            status="DERIVED",
            detail="Small/mid-cap volatility and market-beta sensitivity remain relevant to every ranked setup.",
        ),
        AIEvidence(
            status="UNAVAILABLE",
            detail="Capital-flow and smart-money confirmation is not connected; do not treat volume as wallet-flow evidence.",
        ),
    ]
    if market.btc.trend in {"BEARISH", "MIXED"}:
        major_risks.append(
            AIEvidence(
                status="LIVE",
                detail=f"BTC is {market.btc.trend.lower()} across the available 7D/30D context; alt exposure is beta-sensitive.",
            )
        )
    if market.regime == "RISK-OFF / DEFENSIVE":
        major_risks.append(AIEvidence(status="DERIVED", detail="Broad weakness raises the bar for any new position."))
    opportunities: list[AIOpportunity] = []
    for rank, alpha in enumerate(selected, start=1):
        alpha.rank = rank
        raw = raw_by_id.get(alpha.coin_id, {})
        trade = build_trade_plan(raw, alpha, market)
        opportunities.append(
            AIOpportunity(
                rank=rank,
                asset=alpha.project,
                ticker=alpha.ticker,
                coin_id=alpha.coin_id,
                theme="Momentum + tradable liquidity" if alpha.liquidity is not None else "Live momentum / liquidity data gap",
                score=alpha.alpha_score,
                reason=f"{alpha.catalyst_signal}; momentum composite {alpha.momentum if alpha.momentum is not None else 'unavailable'}% across available live windows.",
                risk=alpha.risk,
                time_horizon="1–4 weeks" if trade.cio_decision.startswith("ACTIONABLE") else "WAIT / undefined",
                trade_candidate=trade.cio_decision.startswith("ACTIONABLE"),
                data_status=trade.data_status,
                evidence=[
                    AIEvidence(status="LIVE", detail=f"Alpha Engine score: {alpha.alpha_score if alpha.alpha_score is not None else 'unavailable'}."),
                    AIEvidence(status="LIVE", detail=f"Market cap {money_text(alpha.market_cap)}; volume {money_text(alpha.volume)}."),
                ],
                trade_plan=trade,
            )
        )
    return AIBriefResponse(
        generated_at=now_iso(),
        mode="DETERMINISTIC_EVIDENCE",
        llm_status="not_configured",
        data_status="LIVE / DERIVED",
        universe_size=len(universe),
        scanned_size=len(candidates),
        excluded_majors=True,
        connection=status("live", "CoinGecko market data is live.", checked_at=checked_at),
        market=market,
        major_risks=major_risks + market_evidence[:1],
        opportunities=opportunities,
        unavailable_data=["capital-flow / smart-money evidence"],
        error=None,
    )


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "main:app",
        host="0.0.0.0",
        port=int(os.getenv("PORT", "8080")),
        reload=False,
    )