# GRIOS Crypto Intelligence Terminal

GRIOS is a dark institutional-style crypto dashboard with a live CoinGecko connection and a High-Growth Alpha Scanner for small- and mid-cap projects.

## What it does

- Shows live CoinGecko connection status.
- Scans a broad CoinGecko market universe.
- Excludes Bitcoin and Ethereum from the default alpha ranking.
- Ranks concrete projects using available market cap, volume, 24-hour, 7-day, and 30-day performance, liquidity/volume, and FDV data.
- Clearly labels live and live/partial data.
- Returns an explicit unavailable, rate-limited, or error state instead of using sample market data.

## Configure CoinGecko

Set the `COINGECKO_API_KEY` environment secret before starting the application. The key is read only by the FastAPI service and is never returned to the browser or written to logs.

In Replit, add it through the Secrets panel:

```text
COINGECKO_API_KEY=<your CoinGecko Demo or Pro key>
```

## Run

The project uses the managed workflows:

```bash
# FastAPI backend
python artifacts/api-server/main.py

# React/Vite dashboard
pnpm --filter @workspace/grios-terminal run dev
```

The API listens on the workflow-provided `PORT` and is routed under `/api`. The dashboard is served at `/`.

## API

```text
GET /api/healthz
GET /api/status
GET /api/alpha/crypto?limit=20&include_majors=false
```

`GET /api/alpha/crypto` returns ranked opportunities with:

- Project and ticker
- Market cap, volume, liquidity, and FDV
- 24-hour, 7-day, and 30-day performance where available
- Catalyst/data signal
- Risk assessment
- Alpha score
- CIO decision
- `available_metrics` and `unavailable_metrics`

If CoinGecko is unavailable or rate-limits the request, the API returns an explicit connection/error response with an empty opportunity list. It does not substitute cached or fabricated market data.

## Development checks

```bash
pnpm --filter @workspace/grios-terminal run typecheck
python -m compileall -q artifacts/api-server/main.py
pnpm --filter @workspace/grios-terminal run build
```

## Extension points

The data provider and scoring logic live in the FastAPI service so additional adapters for Binance, OKX, Supabase, Forex, Stocks, or Telegram can be added without coupling them to the React presentation layer.