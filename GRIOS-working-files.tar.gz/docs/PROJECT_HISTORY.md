# GRIOS Project History and Decision Log

_Last reconstructed: 2026-10-13. Source: accessible GRIOS Codex thread records and the local Git history. This is a sanitized summary, not a full transcript export._

## Timeline

- **2026-07-13 — Memory export attempt.** The accessible memory-export task reported that no stored-memory records were available. Project continuity therefore needs a versioned repository context file, not reliance on model memory.
- **2026-08-05 — GRIOS Art Intelligence concept.** A separate business concept used the GRIOS name for AI-powered premium wall art. Keep it distinct from GRIOS Terminal unless the owner explicitly reconnects them.
- **2026-08-13 — GRIOS repository created.** GitHub `ghanizade-web/GRIOS` initially contained the Replit export archive `ReplitExport-ghanizade.tar.gz`.
- **2026-08-15 through 2026-08-22 — Replit dashboard and migration work.** Conversation summaries describe a Persian-first crypto terminal, CoinGecko/Alpha Engine work, restore of application source, and a move away from Replit toward GitHub, Supabase, Railway/Cloudflare. Exact deployment success was not established in all task records.
- **2026-08-22 onward — Alpha and command workflow.** Desired crypto scan excludes BTC/ETH by default and should focus on small/mid caps; output should expose market cap, volume, momentum, FDV, catalysts, risk and CIO reasoning. The `/start`, `/menu`, `/trades`, `/alpha`, `/report` command family and CIO/Trading/Smart Money/Portfolio modules are design goals.
- **2026-08-20 — Earlier implementation snapshot.** A task summary says three commits were made to optimize the repository. Check Git log for the exact code state before treating the summary as current.
- **2026-08-21 — Hyperliquid exploration.** A task planned secure Hyperliquid data feeding microstructure/scoring. This history does not prove that a production Hyperliquid connector was completed.
- **2026-08-21 — Velo / early-accumulation design.** The desired `/pumpfinder` watchlist tracks price near a stated range low, spot/perpetual volume and delta, open interest changes, funding, liquidations and perp/spot mix. The agreed evidence rule is that Velo is a microstructure source, not proof of smart money: OI alone cannot identify a whale or institution. Confirmation should also use on-chain/exchange/ETF flows, tokenomics and attributable public evidence. Candidate statuses discussed were `PRE-PUMP`, `ENTRY CONFIRMED`, `WATCH`, and `REJECT / NO CHASE`; these remain desired product behavior, not a claim that the current implementation already provides them.
- **2026-09-12 — Cloudflare + Supabase Data Hub.** Repository work added a Cloudflare Worker, Supabase migration, CoinGecko connector, ingestion runs, normalized assets and market snapshots.
- **2026-09-12 — CoinMarketCap + deterministic council.** Local Git history records `1206613 feat: add CoinMarketCap and intelligence council`, including a CMC provider and momentum/liquidity/FDV-dilution/market-regime scoring. Typecheck was reported successful. A natural-language multi-model council was explicitly not complete.
- **2026-09-12 — Cloudflare SPA wiring.** Local changes added a Cloudflare Vite config and Worker static assets. The earlier Vite build attempt failed because the local install lacked the platform-specific Rollup optional dependency. Do not report deployment as complete.
- **2026-09-13 — Work-mode continuity warning.** The project conversation identified a gap between conceptual design in ChatGPT and file/repository changes in Work. A single source of truth was requested to prevent recall loss.
- **2026-09-17 — TradingView MCP setup.** A task title records an attempt to add TradingView MCP. A title alone does not prove the connection was activated or that it is free.
- **2026-09-26 — CryptoRank MCP inspection.** A task title records inspecting the CryptoRank MCP URL. A title alone does not prove live market access or a free plan.
- **2026-10-13 — Multi-market research request.** The owner asked for daily/weekly/monthly/yearly and short/medium/long-term opportunity research, with high accuracy and free data/MCP sources, plus a GitHub backup of project context. Codex confirmed usable CoinGecko, CoinMarketCap and TickerLayer tools. TickerLayer's free plan is suitable for internal MCP research but not redistributing its feed through a public product/API.

## Stable decisions and preferences recorded

- GRIOS Terminal is intended to be Persian-first and command-driven, with a concise investment/research terminal UX.
- Default crypto Alpha scans should not be dominated by BTC and ETH; prefer small/mid-cap candidates only when evidence and liquidity support them.
- Live data must be real and timestamped; if a provider cannot be called or a field is missing, say so rather than fabricate.
- Secrets belong in provider secret stores/environment variables, never source code, frontend bundles or repository history.
- The user repeatedly asked the assistant to execute code/database/repository work end to end with minimal back-and-forth.
- Distinguish code actually present, a local commit, a GitHub commit, an applied migration, and a deployed/verified service. They are separate states.
- The user wants confidence and multiple signals, especially smart-money/flow context. Treat claims of institutional accumulation as unverified hypotheses absent attributable evidence.
- User shared a CoinMarketCap key in an earlier chat. It is deliberately omitted from this record; rotate it if it remains active, and keep future credentials only in secret storage.
- **2026-10-13 — Command UX and low-token preference.** User asked to optimize GRIOS commands and `/menu`, and reduce token use in both Chat and Work. Keep the menu Persian, short, evidence-scoped, and explicit about which modules are implemented versus planned. Prefer compact daily deltas over repeated background/context.

## Sources indexed for continuity

- Codex thread IDs: `01a099fc-1a0f-77e1-98e4-24a68eeb269a`, `01a094d0-d795-7722-a0c9-8e0f1f93d5d1`, `01a0209d-4700-7ff1-80ae-6e5aff5a9de6`, `01a02024-f9b1-72e1-bbd6-65a308c6fe88`, `01a03428-6316-71d3-a045-e69528c0d913`, `01a0344e-232b-7513-b4f5-f0f99a94ffbb`, `019ffa37-6102-7132-a7e9-624dc8e35132`, `019fe7ab-dca2-7753-9e3e-8f0d706ab416`, and the project-wide GRIOS Terminal Commands conversation referenced by prior tasks.
- Repository history at reconstruction: local `main` had three commits beyond the GitHub `main`; GitHub's then-current `main` contained only the Replit archive. Verify both refs before any publication.

## Excluded from this backup

- Raw chat transcripts and uploaded-file contents.
- API keys, bearer tokens, private credentials, database connection strings and account identifiers.
- Raw market-provider payloads and licensed provider data.
- Hidden model memory or internal reasoning. This file only captures project facts and decisions visible in the accessible records.
