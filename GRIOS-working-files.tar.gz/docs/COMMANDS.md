# GRIOS Command Menu

## Live in the current terminal

| Command | Action | Data scope |
| --- | --- | --- |
| `/` | Market overview | Current terminal overview |
| `/alpha` | Crypto opportunity scanner | Small/mid-cap crypto scan; excludes BTC/ETH by default |
| `/ai` | CIO brief | Existing evidence-backed crypto brief |

## Planned; do not present as active until implemented

| Command | Intended action |
| --- | --- |
| `/start` | Show the compact main menu and current data health |
| `/menu` | Show commands grouped by market horizon/module |
| `/trades [symbol] [horizon]` | Research setup with evidence, invalidation and risk; not order execution |
| `/pumpfinder [universe]` | Early-flow proxy scan; distinguish WATCH/PRE-PUMP/confirmed/rejected states |
| `/report [today\|week\|month\|year\|long]` | Compact opportunities report for a selected horizon |
| `/portfolio` | Read-only portfolio/risk summary after a secure portfolio connection exists |
| `/flows [symbol]` | Source-labelled exchange/on-chain/ETF positioning evidence |
| `/macro [region]` | Macro regime using dated primary-source series |

Suggested minimal `/menu` response:

```text
GRIOS
/      نمای کلی بازار
/alpha فرصت‌های کریپتو
/ai    خلاصه CIO

افق پژوهش: today | week | month | year | long
فرمان‌های در حال توسعه: /trades /pumpfinder /report /portfolio /flows /macro
```

Use a market horizon as a parameter wherever possible instead of adding near-duplicate commands. Show planned commands under a separate “در حال توسعه” label until routes and data sources exist.
