# GRIOS Durable Context Changelog

Append one concise entry whenever a lasting decision, capability, source, deployment state, or known risk changes. Use `YYYY-MM-DD`, link relevant commit/PR, and distinguish implemented from planned.

## 2026-10-13

- Added a 15-minute observation-age gate to the deterministic intelligence endpoint. When all latest asset observations are stale or future-dated, the endpoint returns `stale_data` and no ranked candidates.
- Added fresh/stale record counts, freshness threshold, newest usable observation timestamp, and its age to response coverage metadata.
- Confirmed the current live pipeline is crypto-only; daily publication, non-crypto feeds, and institutional-flow confirmation still need separate integrations and deployment verification.
- Added an active hourly Codex heartbeat for this GRIOS chat. It uses TickerLayer for covered cross-market quotes/history, Token Terminal for protocol fundamentals, and Stocktwits as retail sentiment only; it reports source timestamps and says when no high-quality setup is supported.
- Documented that MCP connections power Codex reports but are not credentials/API integrations for the Cloudflare Worker.
- Added horizon-aware Worker opportunity endpoint for day/week/month; year/long explicitly report insufficient history.
- Added provider status/freshness reporting and safer missing market-cap/FDV handling.
- Added Persian-first, token-conscious research rules and sanitized project history.
- Refined the terminal navigation and opportunity scanner labels in Persian.
- Recorded Velo/Hyperliquid and early-flow/PumpFinder design as planned, not connected production features.
- GitHub backup is still pending: GitHub integration currently returns 403 for branch/ref/blob writes. Local repository is three commits ahead of the remote main and has uncommitted changes.
- The public GitHub main contains a Replit archive; keep backup sanitized and never re-upload credentials or raw conversation exports.
- Daily 09:00 Asia/Tehran report is requested. Codex heartbeat can prompt a run, but does not autonomously publish a new message to the same chat. Do not claim otherwise.
- API keys shared in past conversations are omitted from this context. Use provider secret stores only; rotate previously disclosed values where active.
