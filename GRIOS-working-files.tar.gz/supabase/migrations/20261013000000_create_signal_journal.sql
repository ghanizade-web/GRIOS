-- Durable, append-only opportunity journal and scheduled outcome checkpoints.
create table public.opportunity_signals (
  id uuid primary key default gen_random_uuid(),
  fingerprint text not null unique,
  asset_key text not null,
  provider text not null,
  symbol text not null,
  name text not null,
  horizon text not null check (horizon in ('day', 'week', 'month', 'year', 'long')),
  stance text not null check (stance in ('constructive', 'neutral', 'defensive')),
  consensus_score integer not null check (consensus_score between 0 and 100),
  confidence integer not null check (confidence between 0 and 100),
  thesis text not null,
  invalidation text not null,
  source_snapshot_at timestamptz not null,
  entry_price numeric not null check (entry_price > 0),
  metadata jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index opportunity_signals_created_idx on public.opportunity_signals (created_at desc);
create index opportunity_signals_asset_horizon_idx on public.opportunity_signals (asset_key, horizon, created_at desc);

create table public.opportunity_evaluations (
  id bigint generated always as identity primary key,
  signal_id uuid not null references public.opportunity_signals(id),
  checkpoint text not null check (checkpoint in ('1d', '7d', '30d', '90d', '365d')),
  evaluated_at timestamptz not null default now(),
  price numeric not null check (price > 0),
  return_pct numeric not null,
  source_snapshot_at timestamptz not null,
  unique (signal_id, checkpoint)
);

create index opportunity_evaluations_signal_idx on public.opportunity_evaluations (signal_id, checkpoint);

alter table public.opportunity_signals enable row level security;
alter table public.opportunity_evaluations enable row level security;
revoke all on public.opportunity_signals, public.opportunity_evaluations from anon, authenticated;

create view public.opportunity_journal
with (security_invoker = true)
as
select
  signal.id,
  signal.fingerprint,
  signal.asset_key,
  signal.provider,
  signal.symbol,
  signal.name,
  signal.horizon,
  signal.stance,
  signal.consensus_score,
  signal.confidence,
  signal.thesis,
  signal.invalidation,
  signal.source_snapshot_at,
  signal.entry_price,
  signal.metadata,
  signal.created_at,
  coalesce(
    jsonb_agg(
      jsonb_build_object(
        'checkpoint', evaluation.checkpoint,
        'evaluated_at', evaluation.evaluated_at,
        'price', evaluation.price,
        'return_pct', evaluation.return_pct,
        'source_snapshot_at', evaluation.source_snapshot_at
      ) order by evaluation.evaluated_at
    ) filter (where evaluation.id is not null),
    '[]'::jsonb
  ) as evaluations
from public.opportunity_signals signal
left join public.opportunity_evaluations evaluation on evaluation.signal_id = signal.id
group by signal.id;

revoke all on public.opportunity_journal from anon, authenticated;

create view public.opportunity_journal_pending
with (security_invoker = true)
as
select signal.id, signal.asset_key, signal.horizon, signal.created_at,
       signal.entry_price, signal.source_snapshot_at
from public.opportunity_signals signal
where
  (signal.source_snapshot_at <= now() - interval '1 day'
    and not exists (select 1 from public.opportunity_evaluations item where item.signal_id = signal.id and item.checkpoint = '1d'))
  or (signal.source_snapshot_at <= now() - interval '7 days'
    and not exists (select 1 from public.opportunity_evaluations item where item.signal_id = signal.id and item.checkpoint = '7d'))
  or (signal.source_snapshot_at <= now() - interval '30 days'
    and not exists (select 1 from public.opportunity_evaluations item where item.signal_id = signal.id and item.checkpoint = '30d'))
  or (signal.source_snapshot_at <= now() - interval '90 days'
    and not exists (select 1 from public.opportunity_evaluations item where item.signal_id = signal.id and item.checkpoint = '90d'))
  or (signal.source_snapshot_at <= now() - interval '365 days'
    and not exists (select 1 from public.opportunity_evaluations item where item.signal_id = signal.id and item.checkpoint = '365d'))
order by signal.source_snapshot_at asc;

revoke all on public.opportunity_journal_pending from anon, authenticated;
