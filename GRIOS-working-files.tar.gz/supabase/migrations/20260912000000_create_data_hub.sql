-- Sprint 1: provider-neutral market-data hub.
create extension if not exists pgcrypto;

create table public.data_sources (
  id uuid primary key default gen_random_uuid(),
  slug text not null unique check (slug ~ '^[a-z0-9-]+$'),
  display_name text not null,
  status text not null default 'unknown' check (status in ('unknown', 'running', 'healthy', 'degraded', 'disabled')),
  last_started_at timestamptz,
  last_success_at timestamptz,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.assets (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  provider_asset_id text not null,
  symbol text not null,
  name text not null,
  image_url text,
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (provider, provider_asset_id)
);

create table public.ingestion_runs (
  id uuid primary key,
  source_id uuid not null references public.data_sources(id),
  status text not null check (status in ('succeeded', 'failed')),
  started_at timestamptz not null,
  completed_at timestamptz,
  records_received integer not null default 0 check (records_received >= 0),
  records_written integer not null default 0 check (records_written >= 0),
  error_detail text,
  created_at timestamptz not null default now()
);

create table public.market_snapshots (
  id bigint generated always as identity primary key,
  asset_id uuid not null references public.assets(id),
  source_id uuid not null references public.data_sources(id),
  observed_at timestamptz not null,
  ingested_at timestamptz not null default now(),
  price_usd numeric,
  market_cap_usd numeric,
  market_cap_rank integer,
  volume_24h_usd numeric,
  fdv_usd numeric,
  change_24h numeric,
  change_7d numeric,
  change_30d numeric,
  raw_payload jsonb not null,
  unique (asset_id, source_id, observed_at)
);

create index market_snapshots_asset_observed_idx on public.market_snapshots (asset_id, observed_at desc);
create index market_snapshots_source_observed_idx on public.market_snapshots (source_id, observed_at desc);
create index ingestion_runs_source_started_idx on public.ingestion_runs (source_id, started_at desc);

create or replace function public.set_updated_at()
returns trigger
language plpgsql
set search_path = public
as $$
begin
  new.updated_at = now();
  return new;
end;
$$;

create trigger data_sources_set_updated_at before update on public.data_sources
for each row execute function public.set_updated_at();
create trigger assets_set_updated_at before update on public.assets
for each row execute function public.set_updated_at();

-- Security: client roles cannot read raw market payloads or mutate hub tables.
alter table public.data_sources enable row level security;
alter table public.assets enable row level security;
alter table public.ingestion_runs enable row level security;
alter table public.market_snapshots enable row level security;
revoke all on public.data_sources, public.assets, public.ingestion_runs, public.market_snapshots from anon, authenticated;

create view public.latest_market_snapshots
with (security_invoker = true)
as
select distinct on (snapshot.asset_id)
  snapshot.asset_id,
  asset.provider,
  asset.provider_asset_id,
  asset.symbol,
  asset.name,
  asset.image_url,
  snapshot.observed_at,
  snapshot.price_usd,
  snapshot.market_cap_usd,
  snapshot.market_cap_rank,
  snapshot.volume_24h_usd,
  snapshot.fdv_usd,
  snapshot.change_24h,
  snapshot.change_7d,
  snapshot.change_30d
from public.market_snapshots snapshot
join public.assets asset on asset.id = snapshot.asset_id
order by snapshot.asset_id, snapshot.observed_at desc;

revoke all on public.latest_market_snapshots from anon, authenticated;
