# GRIOS Durable Context Changelog

Append one concise entry whenever a lasting decision, capability, source, deployment state, or known risk changes. Use `YYYY-MM-DD`, link relevant commit/PR, and distinguish implemented from planned.

## 2026-10-13

- Rechecked the connected market MCPs: CoinGecko, CoinMarketCap, TickerLayer, Stocktwits, and Token Terminal responded. TickerLayer's current plan did not cover gold, US indices, or US Treasury yields. Responses showed meaningful provider conflicts, so the source map now requires per-source timestamps and metric validation before combining or scoring data.
- Assessed storage options using current official free-tier documentation and the connected Supabase project: retain Supabase for now (Free, active, approximately 11 MB database) because its schema is applied and Worker adapter is in source; document its finite quotas, weekly inactivity pause, and lack of automatic Free backups. Cloudflare D1 is not unlimited either; at the newly configured 10-minute schedule, raw snapshot writes could consume about 72,000 of its 100,000 daily row-write allowance before indexes and other rows.
- Reduced the scheduled Worker market poll from every 5 minutes to every 10 minutes. At 250 listings per provider, that lowers expected monthly requests to about 4,320 each, leaves more room under CoinGecko Demo's 10,000-call allowance and CoinMarketCap Basic's 15,000-credit allowance (which charges additional credits for larger result sets), and remains inside the 15-minute freshness gate. Deployment is still pending, so actual credit usage is not yet measured.
- Checked connected deployment services: GitHub access is available for `ghanizade-web/GRIOS`; no editable Replit app named GRIOS and no Railway service were found in the connected accounts. Cloudflare Worker deployment and secret provisioning remain unverified.
- Refreshed the local Git bundle, source archive, and SHA-256 file after commit `e8372d1`; checksums passed. The GitHub `main` branch was verified at `395e8db3`, whose tree contains only the previously uploaded archive files. A local `git push` could not resolve `github.com`, so the latest code is not on GitHub. Do not retry uploading opaque archives: the earlier public archive upload was rejected by automatic review.
- Restored the Free-plan Supabase project `ghanizade-web's Project` and applied the existing Data Hub migration plus the signal-journal migration. Verified both migration records, journal/evaluation tables and views, RLS, service-role access, and zero public/authenticated read grants. No signal data has been ingested yet; Cloudflare Worker deployment remains pending because the local Wrangler/Vite installation is missing platform-specific optional binaries (`@esbuild/darwin-arm64`, `@rollup/rollup-darwin-arm64`).
- Added an append-only opportunity journal migration, `/v1/journal` read endpoint, hourly-observation deduplication, and scheduled 1d/7d/30d/90d/365d mark-to-market checkpoint evaluation. Fresh Supabase installations must apply the migration; outcomes exclude fees, slippage, and intraperiod drawdown.
- Added a Persian journal page to the terminal, showing recorded constructive signals and average realized checkpoint returns.
- Added a 15-minute observation-age gate to the deterministic intelligence endpoint. When all latest asset observations are stale or future-dated, the endpoint returns `stale_data` and no ranked candidates.
- Added fresh/stale record counts, freshness threshold, newest usable observation timestamp, and its age to response coverage metadata.
- Confirmed the current live pipeline is crypto-only; daily publication, non-crypto feeds, and institutional-flow confirmation still need separate integrations and deployment verification.
- Added an active hourly Codex heartbeat for this GRIOS chat. It uses TickerLayer for covered cross-market quotes/history, Token Terminal for protocol fundamentals, and Stocktwits as retail sentiment only; it reports source timestamps and says when no high-quality setup is supported.
- Documented that MCP connections power Codex reports but are not credentials/API integrations for the Cloudflare Worker.
- Added horizon-aware Worker opportunity endpoint for day/week/month; year/long explicitly report insufficient history.
- Added provider status/freshness reporting and safer missing market-cap/FDV handling.
- Added Persian-first, token-conscious research rules and sanitized project history.
- Refined the terminal navigation and opportunity scanner labels in Persian.
- Recorded Velo/Hyperliquid and early-flow/PumpFinder design as planned, not connected production features.
- The current source archive and Git bundle were added manually to the public GitHub main and their SHA-256 checksums were verified. Local project changes still need a fresh code commit and archive after each implementation update.
- The public GitHub main contains a Replit archive; keep backup sanitized and never re-upload credentials or raw conversation exports.
- Daily 09:00 Asia/Tehran report is requested. Codex heartbeat can prompt a run, but does not autonomously publish a new message to the same chat. Do not claim otherwise.
- API keys shared in past conversations are omitted from this context. Use provider secret stores only; rotate previously disclosed values where active.
