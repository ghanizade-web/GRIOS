import { useMemo, useState } from 'react';
import { AlertTriangle, BrainCircuit, ChevronDown, Database, Gauge, RefreshCw, ShieldAlert, Target, Timer, Waves, X } from 'lucide-react';
import { getGetAiBriefQueryKey, useGetAiBrief, type AIBriefResponse, type AIEvidence, type AIOpportunity, type AITradePlan } from '@workspace/api-client-react';

const dash = (value: string | number | null | undefined) => value === null || value === undefined || value === '' ? '—' : String(value);
const numberValue = (value: number | null | undefined, digits = 2) => value === null || value === undefined ? '—' : value.toLocaleString(undefined, { maximumFractionDigits: digits });
const priceValue = (value: number | null | undefined) => value === null || value === undefined ? '—' : `$${value.toLocaleString(undefined, { maximumFractionDigits: value >= 100 ? 0 : 4 })}`;
const percentValue = (value: number | null | undefined) => value === null || value === undefined ? '—' : `${value >= 0 ? '+' : ''}${value.toFixed(1)}%`;
const confidenceValue = (value: number | null | undefined) => value === null || value === undefined ? '—' : `${(value <= 1 ? value * 100 : value).toFixed(0)}%`;
const titleCase = (value?: string | null) => value ? value.replace(/[_-]/g, ' ').replace(/\b\w/g, char => char.toUpperCase()) : '—';

function EvidencePill({ status }: { status?: string }) {
  const normalized = status?.toUpperCase();
  const style = normalized === 'LIVE'
    ? 'border-[#b8ed64]/30 bg-[#b8ed64]/10 text-[#b8ed64]'
    : normalized === 'DERIVED'
      ? 'border-[#6ed9e6]/30 bg-[#6ed9e6]/10 text-[#6ed9e6]'
      : 'border-[#e1ab50]/35 bg-[#e1ab50]/10 text-[#e1ab50]';
  return <span data-testid={`status-evidence-${normalized?.toLowerCase() || 'unknown'}`} className={`inline-flex items-center gap-1.5 border px-2 py-1 text-[9px] font-bold uppercase tracking-[.14em] ${style}`}><span className="h-1.5 w-1.5 rounded-full bg-current" />{normalized || 'UNAVAILABLE'}</span>;
}

function EvidenceList({ items, compact = false }: { items: AIEvidence[]; compact?: boolean }) {
  if (!items.length) return <span className="text-[11px] text-[#687783]">No evidence returned.</span>;
  return <div className={compact ? 'space-y-2' : 'space-y-3'}>{items.map((item, index) => <div key={`${item.status}-${index}`} className="flex items-start gap-2.5"><EvidencePill status={item.status} /><p className="min-w-0 text-[11px] leading-5 text-[#aab5bc]">{item.detail}</p></div>)}</div>;
}

function BriefHeader({ brief, onRefresh, refreshing }: { brief?: AIBriefResponse; onRefresh: () => void; refreshing: boolean }) {
  return <div className="mb-7 flex flex-col justify-between gap-5 border-b border-[#26323e] pb-7 xl:flex-row xl:items-end">
    <div>
      <div className="mb-3 flex flex-wrap items-center gap-2 text-[10px] font-bold uppercase tracking-[.22em] text-[#768592]"><span className="h-1.5 w-1.5 bg-[#b8ed64]" />Decision surface / autonomous CIO</div>
      <h2 className="max-w-3xl text-[29px] font-extrabold leading-[1.05] tracking-[-.045em] text-[#f0eee7] sm:text-[43px]">The brief, without the <span className="text-[#b8ed64]">fog.</span></h2>
      <p className="mt-4 max-w-2xl text-[13px] leading-6 text-[#8896a2]">One evidence-first read on regime, risk, and actionable setups. The gate is mechanical: candidate plus minimum 2.0 RR.</p>
    </div>
    <div className="flex shrink-0 items-center gap-3">
      <div className="border-l border-[#b8ed64]/40 pl-4 text-[10px] uppercase tracking-[.13em] text-[#83919c]"><div>Generated</div><strong className="mono mt-1 inline-block text-[#d9e3cc]">{brief?.generated_at ? new Date(brief.generated_at).toLocaleString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' }) : '—'}</strong></div>
      <button onClick={onRefresh} disabled={refreshing} data-testid="button-refresh-ai-brief" aria-label="Refresh CIO brief" className="border border-[#293640] p-2.5 text-[#7d8a96] transition hover:border-[#b8ed64]/50 hover:text-[#c8ef83] disabled:opacity-40"><RefreshCw size={15} className={refreshing ? 'animate-spin' : ''} /></button>
    </div>
  </div>;
}

function RegimePanel({ brief }: { brief: AIBriefResponse }) {
  const market = brief.market;
  const btc = market.btc;
  return <section className="border border-[#26323e] bg-[#111820] p-5 sm:p-6">
    <div className="flex flex-wrap items-start justify-between gap-4 border-b border-[#202b35] pb-5"><div><div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.18em] text-[#758391]"><Gauge size={14} className="text-[#b8ed64]" />Current market regime</div><h3 data-testid="text-market-regime" className="mt-3 text-[24px] font-extrabold tracking-[-.03em] text-[#f0eee7]">{titleCase(market.regime)}</h3></div><div className="text-right"><div className="text-[9px] font-bold uppercase tracking-[.16em] text-[#687783]">Risk level</div><div data-testid="status-risk-level" className="mono mt-2 text-[18px] text-[#e1ab50]">{titleCase(market.risk_level)}</div></div></div>
    <p data-testid="text-market-summary" className="mt-5 text-[13px] leading-6 text-[#adb7bf]">{dash(market.summary)}</p>
    <div className="mt-5 grid gap-3 sm:grid-cols-2">
      <div className="border border-[#263640] bg-[#0e151c] p-4"><div className="mb-3 flex items-center justify-between"><div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.16em] text-[#758391]"><Waves size={13} className="text-[#6ed9e6]" />BTC state</div><EvidencePill status={btc.data_status} /></div><div className="flex items-end justify-between gap-3"><div><div data-testid="text-btc-status" className="font-semibold text-[#e7e5dc]">{titleCase(btc.status)}</div><div className="mt-1 text-[11px] text-[#71808c]">{titleCase(btc.trend)}</div></div><div className="text-right"><div className="mono text-[16px] text-[#d9e3cc]">{priceValue(btc.current_price)}</div><div className={`mono mt-1 text-[11px] ${(btc.change_24h ?? 0) >= 0 ? 'text-[#b8ed64]' : 'text-[#ed817a]'}`}>{percentValue(btc.change_24h)} / 24H</div></div></div><div className="mt-4 grid grid-cols-2 gap-2 border-t border-[#202b35] pt-3 text-[10px] text-[#6f7d89]"><span>7D <strong className="mono ml-1 text-[#aebbc1]">{percentValue(btc.change_7d)}</strong></span><span>30D <strong className="mono ml-1 text-[#aebbc1]">{percentValue(btc.change_30d)}</strong></span></div></div>
      <div className="border border-[#263640] bg-[#0e151c] p-4"><div className="mb-3 flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.16em] text-[#758391]"><ShieldAlert size={13} className="text-[#e1ab50]" />Regime evidence</div><EvidenceList items={market.evidence} compact /></div>
    </div>
  </section>;
}

function OpportunityCard({ item }: { item: AIOpportunity }) {
  const [expanded, setExpanded] = useState(false);
  const plan = item.trade_plan;
  const actionable = item.trade_candidate === true && (plan.risk_reward ?? 0) >= 2;
  const positive = item.score !== null && item.score >= 0;
  return <article data-testid={`card-ai-opportunity-${item.coin_id}`} className={`border bg-[#111820] ${actionable ? 'border-[#b8ed64]/45' : 'border-[#26323e]'}`}>
    <div className="p-5 sm:p-6">
      <div className="flex items-start justify-between gap-4"><div className="flex min-w-0 items-start gap-3"><div className={`flex h-9 w-9 shrink-0 items-center justify-center border text-[11px] font-bold ${actionable ? 'border-[#b8ed64]/35 bg-[#b8ed64]/10 text-[#b8ed64]' : 'border-[#30404a] bg-[#19232c] text-[#8d9ba5]'}`}>{String(item.rank).padStart(2, '0')}</div><div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><h3 className="truncate text-[17px] font-bold text-[#eeece4]">{item.asset}</h3><span className="mono text-[10px] uppercase text-[#71808c]">{item.ticker}</span></div><div className="mt-1 text-[11px] text-[#6e7d89]">{item.theme} / {item.time_horizon}</div></div></div><div className={`shrink-0 border px-2 py-1 text-[9px] font-bold uppercase tracking-[.13em] ${actionable ? 'border-[#b8ed64]/35 bg-[#b8ed64]/10 text-[#b8ed64]' : 'border-[#e1ab50]/35 bg-[#e1ab50]/10 text-[#e1ab50]'}`}>{actionable ? 'ACTIONABLE' : 'WAIT'}</div></div>
      <div className="mt-5 grid grid-cols-2 gap-3 border-y border-[#202b35] py-4 sm:grid-cols-5"><div><div className="text-[9px] uppercase tracking-[.14em] text-[#687783]">Score</div><div className={`mono mt-1 text-[17px] ${positive ? 'text-[#b8ed64]' : 'text-[#e1ab50]'}`}>{numberValue(item.score, 1)}</div></div><div><div className="text-[9px] uppercase tracking-[.14em] text-[#687783]">Candidate</div><div className={`mono mt-1 text-[17px] ${item.trade_candidate ? 'text-[#b8ed64]' : 'text-[#e1ab50]'}`}>{item.trade_candidate ? 'YES' : 'NO'}</div></div><div><div className="text-[9px] uppercase tracking-[.14em] text-[#687783]">RR gate</div><div className={`mono mt-1 text-[17px] ${(plan.risk_reward ?? 0) >= 2 ? 'text-[#b8ed64]' : 'text-[#e1ab50]'}`}>{plan.risk_reward === null ? '—' : `${plan.risk_reward.toFixed(2)}x`}</div></div><div><div className="text-[9px] uppercase tracking-[.14em] text-[#687783]">Confidence</div><div className="mono mt-1 text-[17px] text-[#d9e3cc]">{confidenceValue(plan.confidence)}</div></div><div><div className="text-[9px] uppercase tracking-[.14em] text-[#687783]">Risk</div><div className="mt-1 truncate text-[12px] text-[#d5a45e]">{titleCase(item.risk)}</div></div></div>
      <p className="text-[12px] leading-5 text-[#aeb9bf]">{item.reason}</p>
      <div className="mt-4 flex flex-wrap items-center justify-between gap-3"><div className="flex items-center gap-2"><EvidencePill status={item.data_status} /><span className="text-[10px] uppercase tracking-[.12em] text-[#697783]">{plan.cio_decision}</span></div><button onClick={() => setExpanded(value => !value)} aria-expanded={expanded} data-testid={`button-toggle-trade-plan-${item.coin_id}`} className="flex items-center gap-1.5 text-[10px] font-bold uppercase tracking-[.12em] text-[#8c9aa3] hover:text-[#c8f27d]">{expanded ? 'Hide trade plan' : 'Inspect trade plan'}<ChevronDown size={13} className={`transition-transform ${expanded ? 'rotate-180' : ''}`} /></button></div>
    </div>
    {expanded && <TradePlan plan={plan} actionable={actionable} />}
  </article>;
}

function TradePlan({ plan, actionable }: { plan: AITradePlan; actionable: boolean }) {
  return <div className="border-t border-[#26323e] bg-[#0e151c] p-5 sm:p-6">
    <div className="mb-5 flex flex-wrap items-center justify-between gap-3"><div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.18em] text-[#758391]"><Target size={14} className={actionable ? 'text-[#b8ed64]' : 'text-[#e1ab50]'} />Trade plan / {actionable ? 'passes gate' : 'does not pass gate'} <EvidencePill status={plan.data_status} /></div><span className={`mono text-[12px] font-bold ${actionable ? 'text-[#b8ed64]' : 'text-[#e1ab50]'}`}>{actionable ? 'EXECUTE REVIEW' : 'WAIT'}</span></div>
    <div className="grid gap-3 sm:grid-cols-2"><div className="border border-[#24323c] p-3"><div className="text-[9px] font-bold uppercase tracking-[.14em] text-[#657580]">Market state</div><p className="mt-2 text-[11px] leading-5 text-[#b1bdc2]">{dash(plan.market_state)}</p></div><div className="border border-[#24323c] p-3"><div className="text-[9px] font-bold uppercase tracking-[.14em] text-[#657580]">BTC state</div><p className="mt-2 text-[11px] leading-5 text-[#b1bdc2]">{dash(plan.btc_state)}</p></div><div className="border border-[#24323c] p-3"><div className="text-[9px] font-bold uppercase tracking-[.14em] text-[#657580]">Volume / liquidity</div><p className="mt-2 text-[11px] leading-5 text-[#b1bdc2]">{dash(plan.volume_liquidity)}</p></div><div className="border border-[#24323c] p-3"><div className="text-[9px] font-bold uppercase tracking-[.14em] text-[#657580]">Capital flow / smart money</div><p className="mt-2 text-[11px] leading-5 text-[#b1bdc2]">{dash(plan.capital_flow_smart_money)}</p></div></div>
    <div className="mt-3 border border-[#24323c] p-4"><div className="text-[9px] font-bold uppercase tracking-[.14em] text-[#657580]">Technical setup</div><p className="mt-2 text-[12px] leading-5 text-[#c2cbd0]">{dash(plan.technical_setup)}</p></div>
    <div className="mt-3 grid gap-3 lg:grid-cols-[1.25fr_1fr]"><div className="border border-[#24323c] p-4"><div className="mb-3 flex items-center gap-2 text-[9px] font-bold uppercase tracking-[.14em] text-[#657580]"><Timer size={12} />Multi-timeframe context</div><div className="space-y-2">{plan.multi_timeframe.length ? plan.multi_timeframe.map((context, index) => <div key={`${context.timeframe}-${index}`} className="grid grid-cols-[70px_74px_1fr] items-start gap-2 border-t border-[#202b35] pt-2 text-[10px]"><span className="mono text-[#d2d9d8]">{context.timeframe}</span><span className="text-[#b8ed64]">{titleCase(context.state)}</span><span className="leading-4 text-[#84929c]">{context.detail} <span className="text-[#687783]">({percentValue(context.change)} / {context.data_status})</span></span></div>) : <span className="text-[11px] text-[#687783]">No timeframe context returned.</span>}</div></div><div className="border border-[#24323c] p-4"><div className="mb-3 text-[9px] font-bold uppercase tracking-[.14em] text-[#657580]">Levels / payoff</div><div className="grid grid-cols-2 gap-3 text-[10px]"><div><span className="text-[#687783]">Current</span><strong className="mono mt-1 block text-[#c8d3d4]">{priceValue(plan.current_price)}</strong></div><div><span className="text-[#687783]">Entry zone</span><strong className="mono mt-1 block text-[#c8d3d4]">{priceValue(plan.entry_zone_low)} — {priceValue(plan.entry_zone_high)}</strong></div><div><span className="text-[#687783]">Stop</span><strong className="mono mt-1 block text-[#ed817a]">{priceValue(plan.stop)}</strong></div><div><span className="text-[#687783]">Targets</span><strong className="mono mt-1 block text-[#b8ed64]">{plan.targets.length ? plan.targets.map(priceValue).join(' / ') : '—'}</strong></div></div><div className="mt-4 border-t border-[#202b35] pt-3 text-[10px] text-[#71808c]">CIO decision <strong className="ml-2 uppercase text-[#d9e3cc]">{dash(plan.cio_decision)}</strong></div></div></div>
    <div className="mt-3 border border-[#24323c] p-4"><div className="mb-3 flex items-center gap-2 text-[9px] font-bold uppercase tracking-[.14em] text-[#657580]"><Database size={12} />Evidence gaps</div>{plan.unavailable_evidence.length ? <div className="flex flex-wrap gap-2">{plan.unavailable_evidence.map((item, index) => <span key={`${item}-${index}`} className="border border-[#e1ab50]/25 bg-[#e1ab50]/[.06] px-2 py-1 text-[10px] text-[#d5a45e]">{item}</span>)}</div> : <span className="text-[11px] text-[#8da092]">No unavailable evidence reported.</span>}</div>
  </div>;
}

function AiPageContent({ brief, onRefresh, refreshing }: { brief: AIBriefResponse; onRefresh: () => void; refreshing: boolean }) {
  const opportunities = useMemo(() => brief.opportunities || [], [brief.opportunities]);
  const actionable = opportunities.filter(item => item.trade_candidate === true && (item.trade_plan.risk_reward ?? 0) >= 2).length;
  return <div className="mx-auto max-w-[1500px]">
    <BriefHeader brief={brief} onRefresh={onRefresh} refreshing={refreshing} />
    <div className="mb-4 grid gap-4 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
      <div className="border border-[#b8ed64]/30 bg-[#b8ed64]/[.06] p-5"><div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.17em] text-[#b8ed64]"><BrainCircuit size={14} />CIO operating mode</div><div data-testid="text-ai-mode" className="mt-3 text-[19px] font-bold text-[#e7f4d4]">{titleCase(brief.mode)}</div><div className="mt-1 text-[11px] text-[#8fa18c]">LLM status: <span data-testid="status-llm" className="uppercase text-[#c8d3c4]">{brief.llm_status}</span></div></div>
      <div className="border border-[#26323e] bg-[#111820] p-5"><div className="text-[10px] font-bold uppercase tracking-[.17em] text-[#687783]">Data status</div><div className="mt-3"><EvidencePill status={brief.data_status} /></div></div>
      <div className="border border-[#26323e] bg-[#111820] p-5"><div className="text-[10px] font-bold uppercase tracking-[.17em] text-[#687783]">Universe / scanned</div><div data-testid="text-ai-coverage" className="mono mt-3 text-[19px] text-[#6ed9e6]">{numberValue(brief.scanned_size, 0)} <span className="text-[12px] text-[#6f7d89]">/ {numberValue(brief.universe_size, 0)}</span></div></div>
      <div className="border border-[#26323e] bg-[#111820] p-5"><div className="text-[10px] font-bold uppercase tracking-[.17em] text-[#687783]">Passed RR gate</div><div data-testid="text-actionable-count" className={`mono mt-3 text-[19px] ${actionable ? 'text-[#b8ed64]' : 'text-[#e1ab50]'}`}>{actionable} <span className="text-[12px] text-[#6f7d89]">/ {opportunities.length}</span></div></div>
    </div>
    <div className="mb-4 grid gap-4 xl:grid-cols-[1.15fr_.85fr]"><RegimePanel brief={brief} /><section className="border border-[#26323e] bg-[#111820] p-5 sm:p-6"><div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.18em] text-[#758391]"><AlertTriangle size={14} className="text-[#e1ab50]" />Major risks</div><div className="mt-5"><EvidenceList items={brief.major_risks} /></div>{brief.unavailable_data.length > 0 && <div className="mt-5 border-t border-[#202b35] pt-4 text-[11px] leading-5 text-[#d5a45e]">Unavailable: {brief.unavailable_data.join(', ')}</div>}</section></div>
    <section className="border border-[#26323e] bg-[#0f161d]"><div className="flex flex-wrap items-end justify-between gap-3 border-b border-[#26323e] px-5 py-5 sm:px-6"><div><div className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-[.18em] text-[#758391]"><Target size={14} className="text-[#b8ed64]" />Top opportunities</div><p className="mt-2 text-[12px] text-[#6f7d89]">Candidate status is subordinate to the RR gate. Inspect evidence before committee discussion.</p></div><div className="mono text-[10px] uppercase tracking-[.12em] text-[#6f7d89]">Trade candidate + RR ≥ 2.00 = actionable</div></div><div className="grid gap-4 p-4 sm:p-5 xl:grid-cols-2">{opportunities.map(item => <OpportunityCard key={item.coin_id} item={item} />)}</div></section>
  </div>;
}

export default function AiPage() {
  const params = { limit: 8 };
  const ai = useGetAiBrief(params, { query: { queryKey: getGetAiBriefQueryKey(params), staleTime: 30000 } });
  if (ai.isLoading) return <AiState type="loading" />;
  if (ai.isError) return <AiState type="error" message="The CIO brief could not be retrieved from the intelligence endpoint." onRetry={() => ai.refetch()} />;
  if (!ai.data) return <AiState type="empty" />;
  return <div className="terminal-grid min-h-[calc(100dvh-76px)] px-5 py-7 sm:px-8 sm:py-10"><AiPageContent brief={ai.data} onRefresh={() => ai.refetch()} refreshing={ai.isFetching} /></div>;
}

function AiState({ type, message, onRetry }: { type: 'loading' | 'error' | 'empty'; message?: string; onRetry?: () => void }) {
  if (type === 'loading') return <div className="terminal-grid min-h-[calc(100dvh-76px)] px-5 py-7 sm:px-8 sm:py-10"><div className="mx-auto max-w-[1500px]"><div className="mb-7 border-b border-[#26323e] pb-7"><div className="skeleton h-3 w-48" /><div className="skeleton mt-4 h-11 w-[min(560px,90%)]" /><div className="skeleton mt-4 h-4 w-[min(650px,90%)]" /></div><div className="grid gap-4 md:grid-cols-4">{[1, 2, 3, 4].map(item => <div key={item} className="skeleton h-28" />)}</div><div className="mt-4 grid gap-4 xl:grid-cols-2">{[1, 2].map(item => <div key={item} className="skeleton h-72" />)}</div><div className="mt-4 grid gap-4 xl:grid-cols-2">{[1, 2, 3, 4].map(item => <div key={item} className="skeleton h-80" />)}</div></div></div>;
  return <div className="terminal-grid flex min-h-[calc(100dvh-76px)] items-center justify-center px-5 py-10"><div className="max-w-md border border-[#26323e] bg-[#111820] p-8 text-center"><div className="mx-auto flex h-10 w-10 items-center justify-center border border-[#e1ab50]/40 text-[#e1ab50]">{type === 'error' ? <X size={18} /> : <Database size={18} />}</div><h2 className="mt-5 text-[17px] font-bold text-[#eeece4]">{type === 'error' ? 'CIO brief unavailable' : 'No brief returned'}</h2><p className="mt-2 text-[12px] leading-5 text-[#8796a0]">{message || 'The intelligence endpoint returned no decision surface for this scan.'}</p>{onRetry && <button onClick={onRetry} data-testid="button-retry-ai-brief" className="mt-5 inline-flex items-center gap-2 border border-[#b8ed64]/35 px-4 py-2 text-[10px] font-bold uppercase tracking-[.12em] text-[#b8ed64] hover:bg-[#b8ed64]/10"><RefreshCw size={13} />Retry brief</button>}</div></div>;
}