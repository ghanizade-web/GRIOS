# GRIOS Crypto Intelligence Terminal

Live crypto intelligence terminal for ranking small- and mid-cap projects using CoinGecko market data.

## Run & Operate

- `python artifacts/api-server/main.py` — run the FastAPI API server
- `pnpm --filter @workspace/grios-terminal run dev` — run the React dashboard
- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from the OpenAPI spec
- Required secret: `COINGECKO_API_KEY`

## Stack

- pnpm workspaces, Node.js 24, TypeScript 5.9
- API: Express 5
- DB: PostgreSQL + Drizzle ORM
- Validation: Zod (`zod/v4`), `drizzle-zod`
- API codegen: Orval (from OpenAPI spec)
- Build: esbuild (CJS bundle)

## Where things live

- `artifacts/api-server/main.py` — FastAPI routes, CoinGecko adapter, scanner scoring
- `artifacts/grios-terminal/src/App.tsx` — dashboard shell and live API hook consumers
- `artifacts/grios-terminal/src/index.css` — GRIOS visual tokens and responsive terminal styling
- `lib/api-spec/openapi.yaml` — source-of-truth API contract
- `README.md` — configuration, run, and endpoint instructions

## Architecture decisions

- CoinGecko data is requested live on each scanner/status query; no fabricated fallback data is used.
- Bitcoin and Ethereum are excluded from the alpha scanner by default and can be included only with an explicit query parameter.
- Missing provider metrics remain `null` and are surfaced through `available_metrics` / `unavailable_metrics`.
- The backend is a standalone FastAPI service so future exchange and asset-class adapters can be added independently.

## Product

The terminal exposes live connection health, broad universe coverage, scanner methodology, and CIO-oriented ranked opportunities. The `/alpha` route provides a focused scanner view with adjustable result depth.

## User preferences

No additional user preferences recorded.

## Gotchas

- Keep `COINGECKO_API_KEY` in Replit Secrets; never put it in frontend code or logs.
- Re-run API codegen after changing `lib/api-spec/openapi.yaml`.

## Pointers

- See the `pnpm-workspace` skill for workspace structure, TypeScript setup, and package details
