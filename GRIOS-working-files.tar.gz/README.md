# GRIOS Crypto Intelligence Terminal

GRIOS is a dark institutional-style crypto dashboard with a live CoinGecko connection and a High-Growth Alpha Scanner for small- and mid-cap projects.

## What it does

- Shows live CoinGecko connection status.
- Scans a broad CoinGecko market universe.
- Excludes Bitcoin and Ethereum from the default alpha ranking.
- Ranks concrete projects using available market cap, volume, 24-hour, 7-day, and 30-day performance, liquidity/volume, and FDV data.
- Clearly labels live and live/partial data.
- Returns an explicit unavailable, rate-limited, or error state instead of using sample market data.

## Sprint 1 architecture

`services/data-hub-worker` is the production ingestion boundary. Its scheduled
Cloudflare Worker fetches CoinGecko and CoinMarketCap every five minutes, normalizes the market
universe, and writes an immutable snapshot history into Supabase. The public
Worker API serves only the latest normalized rows; it never exposes provider
credentials or raw provider payloads.

The same Worker deploys the production React terminal as a Cloudflare Static
Asset SPA; `/healthz` and `/v1/*` remain dynamic Worker routes.

The existing FastAPI scanner remains available during the migration. New data
providers should implement a connector in `services/data-hub-worker/src/` and
write to the same asset/snapshot contract.

## Configure CoinGecko and Supabase

Set the `COINGECKO_API_KEY` and `COINMARKETCAP_API_KEY` environment secrets before starting the application.
For the Worker, also set `SUPABASE_URL` and the current Supabase server-only
`SUPABASE_SECRET_KEY`. These values are never returned to the browser or
written to logs.

In Replit, add it through the Secrets panel:

```text
COINGECKO_API_KEY=<your CoinGecko Demo or Pro key>
COINMARKETCAP_API_KEY=<your CoinMarketCap Pro key>
SUPABASE_URL=https://<project-ref>.supabase.co
SUPABASE_SECRET_KEY=sb_secret_<your-secret-key>
```

## Run

The project uses the managed workflows:

```bash
# FastAPI backend
python artifacts/api-server/main.py

# React/Vite dashboard
pnpm --filter @workspace/grios-terminal run dev
```

The API listens on the workflow-provided `PORT` and is routed under `/api`. The dashboard is served at `/`.

## API

```text
GET /api/healthz
GET /api/status
GET /api/alpha/crypto?limit=20&include_majors=false
```

The Data Hub Worker adds:

```text
GET /healthz
GET /v1/markets/latest?limit=50
GET /v1/intelligence?command=top%20gainers
GET /v1/opportunities?horizon=day
GET /v1/opportunities?horizon=week
GET /v1/opportunities?horizon=month
GET /v1/opportunities?horizon=year
GET /v1/status
```

The opportunity endpoint currently ranks the stored crypto universe for daily,
weekly, or monthly horizons. Annual and long-term requests return
`insufficient_history` until 90d/365d history, drawdown, fundamentals, and
catalyst evidence are collected. It intentionally returns no fabricated
long-term ranking. Daily/weekly/monthly rankings are suppressed with
`stale_data` if no latest asset observation is within 15 minutes; the response
includes the usable-record count and freshest-observation age.

Project continuity, command definitions and research rules are documented in
[`docs/GRIOS_MASTER.md`](docs/GRIOS_MASTER.md),
[`docs/PROJECT_HISTORY.md`](docs/PROJECT_HISTORY.md),
[`docs/OPPORTUNITY_RESEARCH.md`](docs/OPPORTUNITY_RESEARCH.md),
[`docs/COMMANDS.md`](docs/COMMANDS.md), and
[`docs/CHANGELOG_CONTEXT.md`](docs/CHANGELOG_CONTEXT.md). The history document
is a sanitized decision log, not a verbatim conversation export.

`/healthz` is a liveness check. `/v1/status` reports each configured market
provider's last successful ingestion and marks data older than 15 minutes as
stale; it never returns provider credentials or raw error text.

## Deploy the Data Hub

1. Apply `supabase/migrations/20260912000000_create_data_hub.sql` to the linked Supabase project.
2. Copy `services/data-hub-worker/.dev.vars.example` to `.dev.vars` for local development.
3. Configure the three required secrets in Cloudflare, then deploy:

```bash
pnpm --filter @workspace/data-hub-worker run deploy
```

The Worker configuration validates that its secrets exist before deployment.

`GET /api/alpha/crypto` returns ranked opportunities with:

- Project and ticker
- Market cap, volume, liquidity, and FDV
- 24-hour, 7-day, and 30-day performance where available
- Catalyst/data signal
- Risk assessment
- Alpha score
- CIO decision
- `available_metrics` and `unavailable_metrics`

If CoinGecko is unavailable or rate-limits the request, the API returns an explicit connection/error response with an empty opportunity list. It does not substitute cached or fabricated market data.

## Development checks

```bash
pnpm --filter @workspace/grios-terminal run typecheck
python -m compileall -q artifacts/api-server/main.py
pnpm --filter @workspace/grios-terminal run build
```

## Extension points

The data provider and scoring logic live in the FastAPI service so additional adapters for Binance, OKX, Supabase, Forex, Stocks, or Telegram can be added without coupling them to the React presentation layer.
