export interface Env {
  COINGECKO_API_KEY: string;
  COINMARKETCAP_API_KEY: string;
  SUPABASE_URL: string;
  SUPABASE_SECRET_KEY: string;
}

export interface NormalizedMarket {
  providerAssetId: string;
  symbol: string;
  name: string;
  imageUrl: string | null;
  observedAt: string;
  priceUsd: number | null;
  marketCapUsd: number | null;
  marketCapRank: number | null;
  volume24hUsd: number | null;
  fdvUsd: number | null;
  change24h: number | null;
  change7d: number | null;
  change30d: number | null;
  rawPayload: unknown;
}

export interface CoinGeckoMarket {
  id: string;
  symbol: string;
  name: string;
  image: string | null;
  current_price: number | null;
  market_cap: number | null;
  market_cap_rank: number | null;
  total_volume: number | null;
  fully_diluted_valuation: number | null;
  price_change_percentage_24h: number | null;
  price_change_percentage_7d_in_currency: number | null;
  price_change_percentage_30d_in_currency: number | null;
  last_updated: string | null;
}

export interface AssetRecord {
  id: string;
  provider: string;
  provider_asset_id: string;
  symbol: string;
  name: string;
  image_url: string | null;
}

export interface MarketSnapshotInput {
  asset_id: string;
  source_id: string;
  observed_at: string;
  price_usd: number | null;
  market_cap_usd: number | null;
  market_cap_rank: number | null;
  volume_24h_usd: number | null;
  fdv_usd: number | null;
  change_24h: number | null;
  change_7d: number | null;
  change_30d: number | null;
  raw_payload: CoinGeckoMarket;
}
