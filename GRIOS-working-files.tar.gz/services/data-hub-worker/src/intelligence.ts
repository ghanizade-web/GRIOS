export interface MarketRow {
  provider: string;
  symbol: string;
  name: string;
  observed_at: string;
  price_usd: number | null;
  market_cap_usd: number | null;
  market_cap_rank: number | null;
  volume_24h_usd: number | null;
  fdv_usd: number | null;
  change_24h: number | null;
  change_7d: number | null;
  change_30d: number | null;
}

export type OpportunityHorizon = "day" | "week" | "month" | "year" | "long";
const MAX_OBSERVATION_AGE_SECONDS = 15 * 60;

type AgentName = "momentum" | "liquidity" | "risk" | "market-regime";
interface AgentFinding {
  agent: AgentName;
  score: number | null;
  rationale: string;
  evidence: string[];
}

export function buildIntelligence(
  command: string,
  rows: MarketRow[],
  horizon: OpportunityHorizon = "week",
) {
  const normalizedCommand = command.trim().toLowerCase();
  const horizonDataAvailable = horizon !== "year" && horizon !== "long";
  const uniqueRows = latestPerAsset(rows);
  const now = Date.now();
  const freshRows = uniqueRows.filter((row) => {
    const observedAt = Date.parse(row.observed_at);
    const ageSeconds = (now - observedAt) / 1000;
    return (
      Number.isFinite(observedAt) &&
      ageSeconds >= 0 &&
      ageSeconds <= MAX_OBSERVATION_AGE_SECONDS
    );
  });
  const freshestObservation = freshRows.reduce<string | null>(
    (latest, row) =>
      !latest || row.observed_at > latest ? row.observed_at : latest,
    null,
  );
  const freshestAgeSeconds = freshestObservation
    ? Math.max(0, Math.floor((now - Date.parse(freshestObservation)) / 1000))
    : null;
  const dataIsFresh = freshRows.length > 0;
  const freshRowsSet = new Set(freshRows);
  const candidates = uniqueRows
    .filter((row) => dataIsFresh && freshRowsSet.has(row))
    .map((row) => ({ row, council: evaluateCouncil(row, freshRows, horizon) }))
    .filter(({ row }) => matchesCommand(row, normalizedCommand))
    .sort((a, b) => b.council.consensus_score - a.council.consensus_score);

  return {
    command: command.trim(),
    horizon,
    status: !horizonDataAvailable
      ? "insufficient_history"
      : dataIsFresh
        ? "ranked"
        : "stale_data",
    generated_at: new Date(now).toISOString(),
    scope: "crypto",
    data_coverage: {
      records: freshRows.length,
      stale_records: Math.max(0, uniqueRows.length - freshRows.length),
      providers: [...new Set(freshRows.map((row) => row.provider))],
      available_return_windows: ["24h", "7d", "30d"],
      freshness_threshold_seconds: MAX_OBSERVATION_AGE_SECONDS,
      freshest_observation: freshestObservation,
      freshest_age_seconds: freshestAgeSeconds,
    },
    method:
      "Deterministic evidence-scored research screen. It is not a trade instruction or financial advice.",
    limitation: !horizonDataAvailable
      ? "The stored dataset has no 90d/365d performance history or audited fundamentals; a long-horizon ranking would be unsupported."
      : dataIsFresh
        ? null
        : "No observation is within the 15-minute freshness window. Results are suppressed until current data is available.",
    required_data: horizonDataAvailable
      ? []
      : [
          "90d and 365d price history",
          "drawdown and volatility",
          "audited fundamentals",
          "catalyst and source records",
        ],
    results: (horizonDataAvailable ? candidates.slice(0, 25) : []).map(
      ({ row, council }) => ({
        asset: { symbol: row.symbol, name: row.name, provider: row.provider },
        consensus: council,
        market: {
          price_usd: row.price_usd,
          market_cap_usd: row.market_cap_usd,
          volume_24h_usd: row.volume_24h_usd,
          change_24h: row.change_24h,
          change_7d: row.change_7d,
          change_30d: row.change_30d,
          observed_at: row.observed_at,
        },
      }),
    ),
  };
}

function matchesCommand(row: MarketRow, command: string): boolean {
  if (!command || command === "market overview") return true;
  const identity = `${row.symbol} ${row.name}`.toLowerCase();
  if (command.includes("gainer") || command.includes("momentum"))
    return (row.change_24h ?? 0) > 0;
  if (command.includes("loser") || command.includes("risk"))
    return (row.change_24h ?? 0) < 0;
  if (command.includes("liquid")) return (row.volume_24h_usd ?? 0) > 0;
  return (
    identity.includes(command.replace(/[^a-z0-9 ]/g, "").trim()) ||
    command.includes("overview")
  );
}

function evaluateCouncil(
  row: MarketRow,
  universe: MarketRow[],
  horizon: OpportunityHorizon,
) {
  const findings: AgentFinding[] = [
    momentumFinding(row, horizon),
    liquidityFinding(row),
    riskFinding(row),
    regimeFinding(universe),
  ];
  const scored = findings.filter((finding) => finding.score !== null) as Array<
    AgentFinding & { score: number }
  >;
  const consensusScore = scored.length
    ? Math.round(
        scored.reduce((sum, finding) => sum + finding.score, 0) / scored.length,
      )
    : 0;
  return {
    stance:
      consensusScore >= 65
        ? "constructive"
        : consensusScore >= 45
          ? "neutral"
          : "defensive",
    consensus_score: consensusScore,
    confidence: Math.round((scored.length / findings.length) * 100),
    dissent: findings
      .filter(
        (finding) =>
          finding.score !== null &&
          Math.abs(finding.score - consensusScore) >= 25,
      )
      .map((finding) => finding.agent),
    findings,
  };
}

function momentumFinding(
  row: MarketRow,
  horizon: OpportunityHorizon,
): AgentFinding {
  const valueByHorizon: Partial<Record<OpportunityHorizon, number | null>> = {
    day: row.change_24h,
    week: row.change_7d,
    month: row.change_30d,
  };
  const value = valueByHorizon[horizon];
  if (value === undefined || value === null)
    return unavailable(
      "momentum",
      horizon === "year" || horizon === "long"
        ? "Annual return history is not stored."
        : `No ${horizon} return data is available.`,
    );
  return finding(
    "momentum",
    clamp(50 + value, 0, 100),
    `${horizon} return is ${value.toFixed(1)}%.`,
    [
      horizon === "day"
        ? "24h provider return"
        : horizon === "week"
          ? "7d provider return"
          : "30d provider return",
    ],
  );
}

function liquidityFinding(row: MarketRow): AgentFinding {
  if (!row.volume_24h_usd || !row.market_cap_usd)
    return unavailable("liquidity", "Volume or market cap is unavailable.");
  const turnover = (row.volume_24h_usd / row.market_cap_usd) * 100;
  return finding(
    "liquidity",
    clamp(turnover * 3, 0, 100),
    `24h turnover is ${turnover.toFixed(1)}% of market cap.`,
    ["24h volume / market cap"],
  );
}

function riskFinding(row: MarketRow): AgentFinding {
  if (
    row.market_cap_usd === null ||
    row.market_cap_usd <= 0 ||
    row.fdv_usd === null ||
    row.fdv_usd <= 0
  )
    return unavailable("risk", "Market cap or FDV is unavailable.");
  const dilution = row.fdv_usd / row.market_cap_usd;
  const score = dilution <= 1.25 ? 80 : dilution <= 2 ? 55 : 25;
  return finding(
    "risk",
    score,
    `FDV / market-cap dilution ratio is ${dilution.toFixed(2)}x.`,
    ["fully diluted valuation", "market cap"],
  );
}

function regimeFinding(universe: MarketRow[]): AgentFinding {
  const changes = latestPerAsset(universe)
    .map((row) => row.change_24h)
    .filter((value): value is number => value !== null);
  if (!changes.length)
    return unavailable("market-regime", "No market-wide 24h return data.");
  const average =
    changes.reduce((sum, value) => sum + value, 0) / changes.length;
  return finding(
    "market-regime",
    clamp(50 + average * 2, 0, 100),
    `Average 24h return across the stored universe is ${average.toFixed(1)}%.`,
    ["cross-asset 24h returns"],
  );
}

function latestPerAsset(rows: MarketRow[]): MarketRow[] {
  const latest = new Map<string, MarketRow>();
  for (const row of rows) {
    const key = `${row.symbol.trim().toLowerCase()}|${row.name.trim().toLowerCase()}`;
    const existing = latest.get(key);
    if (!existing || row.observed_at > existing.observed_at)
      latest.set(key, row);
  }
  return [...latest.values()];
}

function finding(
  agent: AgentName,
  score: number,
  rationale: string,
  evidence: string[],
): AgentFinding {
  return { agent, score: Math.round(score), rationale, evidence };
}
function unavailable(agent: AgentName, rationale: string): AgentFinding {
  return { agent, score: null, rationale, evidence: [] };
}
function clamp(value: number, min: number, max: number) {
  return Math.min(Math.max(value, min), max);
}
