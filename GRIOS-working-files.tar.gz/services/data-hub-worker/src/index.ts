import { ingestAllSources } from "./data-hub";
import {
  buildIntelligence,
  type MarketRow,
  type OpportunityHorizon,
} from "./intelligence";
import { SupabaseGateway } from "./supabase";
import type { Env } from "./types";

const jsonHeaders = { "content-type": "application/json; charset=utf-8" };
interface SchedulerEvent {
  readonly scheduledTime: number;
  readonly cron: string;
}
interface WorkerExecutionContext {
  waitUntil(promise: Promise<unknown>): void;
}

export default {
  async fetch(request: Request, env: Env): Promise<Response> {
    const url = new URL(request.url);
    if (request.method !== "GET")
      return json({ error: "Method not allowed" }, 405);

    if (url.pathname === "/healthz") {
      return json({ service: "grios-data-hub", status: "ok" });
    }
    if (url.pathname === "/v1/status") {
      try {
        const response = await new SupabaseGateway(env).sourceStatuses();
        const sources = (await response.json()) as Array<{
          slug: string;
          display_name: string;
          status: string;
          last_started_at: string | null;
          last_success_at: string | null;
          last_error: string | null;
        }>;
        const now = Date.now();
        const providers = sources.map((source) => {
          const lastSuccess = source.last_success_at
            ? Date.parse(source.last_success_at)
            : null;
          const ageSeconds =
            lastSuccess === null
              ? null
              : Math.max(0, (now - lastSuccess) / 1000);
          const stale = ageSeconds === null || ageSeconds > 15 * 60;
          return {
            provider: source.slug,
            name: source.display_name,
            status:
              stale && source.status === "healthy" ? "stale" : source.status,
            last_started_at: source.last_started_at,
            last_success_at: source.last_success_at,
            age_seconds: ageSeconds === null ? null : Math.floor(ageSeconds),
            has_error: Boolean(source.last_error),
          };
        });
        const ready =
          providers.length > 0 &&
          providers.every((provider) => provider.status === "healthy");
        return json({
          service: "grios-data-hub",
          status: ready
            ? "healthy"
            : providers.length
              ? "degraded"
              : "initializing",
          generated_at: new Date(now).toISOString(),
          freshness_threshold_seconds: 900,
          providers,
        });
      } catch (error) {
        console.error("provider-status-query-failed", error);
        return json({ service: "grios-data-hub", status: "unavailable" }, 503);
      }
    }
    if (url.pathname === "/v1/markets/latest") {
      const requestedLimit = Number(url.searchParams.get("limit") ?? "50");
      const limit = Number.isInteger(requestedLimit)
        ? Math.min(Math.max(requestedLimit, 1), 250)
        : 50;
      try {
        const response = await new SupabaseGateway(env).latestMarkets(limit);
        return new Response(response.body, { headers: jsonHeaders });
      } catch (error) {
        console.error("latest-market-query-failed", error);
        return json({ error: "Market data is currently unavailable." }, 503);
      }
    }
    if (
      url.pathname === "/v1/intelligence" ||
      url.pathname === "/v1/opportunities"
    ) {
      const command =
        url.searchParams.get("command")?.slice(0, 160) ?? "market overview";
      const horizon = parseHorizon(url.searchParams.get("horizon"));
      try {
        const response = await new SupabaseGateway(env).latestMarkets(250);
        return json(
          buildIntelligence(
            command,
            (await response.json()) as MarketRow[],
            horizon,
          ),
        );
      } catch (error) {
        console.error("intelligence-query-failed", error);
        return json(
          { error: "Intelligence data is currently unavailable." },
          503,
        );
      }
    }
    return json({ error: "Not found" }, 404);
  },

  async scheduled(
    _event: SchedulerEvent,
    env: Env,
    ctx: WorkerExecutionContext,
  ): Promise<void> {
    ctx.waitUntil(
      ingestAllSources(env).then((results) =>
        results.forEach((result) => {
          if (result.status === "rejected")
            console.error("provider-ingestion-failed", result.reason);
        }),
      ),
    );
  },
};

function json(value: unknown, status = 200): Response {
  return new Response(JSON.stringify(value), { status, headers: jsonHeaders });
}

function parseHorizon(value: string | null): OpportunityHorizon {
  switch (value?.trim().toLowerCase()) {
    case "day":
    case "daily":
    case "today":
    case "1d":
      return "day";
    case "week":
    case "weekly":
    case "1w":
    case "7d":
      return "week";
    case "month":
    case "monthly":
    case "1m":
    case "30d":
      return "month";
    case "year":
    case "yearly":
    case "annual":
    case "1y":
      return "year";
    case "long":
    case "long-term":
    case "long_term":
      return "long";
    default:
      return "week";
  }
}
