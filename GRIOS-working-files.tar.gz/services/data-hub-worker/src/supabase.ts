import type { Env } from "./types";

/** Minimal PostgREST gateway. Its secret key is confined to the Worker binding. */
export class SupabaseGateway {
  private readonly baseUrl: string;

  constructor(private readonly env: Env) {
    this.baseUrl = `${env.SUPABASE_URL.replace(/\/$/, "")}/rest/v1`;
  }

  async upsert(
    table: string,
    rows: unknown,
    onConflict: string,
  ): Promise<Response> {
    return this.request(
      table,
      {
        method: "POST",
        headers: {
          Prefer: "resolution=merge-duplicates,return=representation",
        },
        body: JSON.stringify(rows),
      },
      `on_conflict=${encodeURIComponent(onConflict)}`,
    );
  }

  async insert(table: string, rows: unknown): Promise<Response> {
    return this.request(table, {
      method: "POST",
      headers: { Prefer: "return=minimal" },
      body: JSON.stringify(rows),
    });
  }

  async latestMarkets(limit: number): Promise<Response> {
    return this.request(
      "latest_market_snapshots",
      { method: "GET" },
      `select=*&order=market_cap_usd.desc.nullslast&limit=${limit}`,
    );
  }

  async sourceStatuses(): Promise<Response> {
    return this.request(
      "data_sources",
      { method: "GET" },
      "select=slug,display_name,status,last_started_at,last_success_at,last_error&order=display_name.asc",
    );
  }

  private async request(
    path: string,
    init: RequestInit,
    query?: string,
  ): Promise<Response> {
    const response = await fetch(
      `${this.baseUrl}/${path}${query ? `?${query}` : ""}`,
      {
        ...init,
        headers: {
          apikey: this.env.SUPABASE_SECRET_KEY,
          authorization: `Bearer ${this.env.SUPABASE_SECRET_KEY}`,
          "content-type": "application/json",
          ...init.headers,
        },
        signal: AbortSignal.timeout(15_000),
      },
    );

    if (!response.ok) {
      throw new Error(
        `Supabase ${path} request failed with HTTP ${response.status}.`,
      );
    }
    return response;
  }
}
