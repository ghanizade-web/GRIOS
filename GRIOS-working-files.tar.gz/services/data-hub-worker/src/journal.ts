import { SupabaseGateway } from "./supabase";
import type { Env } from "./types";
import type { MarketRow, OpportunityHorizon } from "./intelligence";

const HORIZON_CHECKPOINTS: Record<OpportunityHorizon, readonly string[]> = {
  day: ["1d", "7d", "30d", "90d", "365d"],
  week: ["1d", "7d", "30d", "90d", "365d"],
  month: ["1d", "7d", "30d", "90d", "365d"],
  year: ["1d", "7d", "30d", "90d", "365d"],
  long: ["1d", "7d", "30d", "90d", "365d"],
};
const CHECKPOINT_AGE_MS: Record<string, number> = {
  "1d": 24 * 60 * 60 * 1000,
  "7d": 7 * 24 * 60 * 60 * 1000,
  "30d": 30 * 24 * 60 * 60 * 1000,
  "90d": 90 * 24 * 60 * 60 * 1000,
  "365d": 365 * 24 * 60 * 60 * 1000,
};
const MAX_EVALUATION_AGE_MS = 30 * 60 * 1000;

export interface JournalSignal {
  asset: { symbol: string; name: string; provider: string };
  horizon: OpportunityHorizon;
  consensus: {
    stance: "constructive" | "neutral" | "defensive";
    consensus_score: number;
    confidence: number;
    findings: Array<{
      agent: string;
      score: number | null;
      rationale: string;
      evidence: string[];
    }>;
  };
  market: { price_usd: number | null; observed_at: string };
}

export async function recordSignals(
  env: Env,
  signals: JournalSignal[],
  thesisFor: (signal: JournalSignal) => string,
  invalidationFor: (signal: JournalSignal) => string,
) {
  const eligible = signals.filter(
    (signal) =>
      signal.consensus.stance === "constructive" &&
      signal.consensus.consensus_score >= 65 &&
      signal.market.price_usd !== null &&
      signal.market.price_usd > 0,
  );
  if (!eligible.length) return { recorded: 0, skipped: signals.length };

  const rows = eligible.map((signal) => {
    const assetKey = `${signal.asset.provider}:${signal.asset.name.trim().toLowerCase()}`;
    const observationTime = Date.parse(signal.market.observed_at);
    const observationHour = Number.isFinite(observationTime)
      ? new Date(
          Math.floor(observationTime / 3_600_000) * 3_600_000,
        ).toISOString()
      : signal.market.observed_at;
    const fingerprint = `${assetKey}|${signal.horizon}|${observationHour}`;
    return {
      fingerprint,
      asset_key: assetKey,
      provider: signal.asset.provider,
      symbol: signal.asset.symbol,
      name: signal.asset.name,
      horizon: signal.horizon,
      stance: signal.consensus.stance,
      consensus_score: signal.consensus.consensus_score,
      confidence: signal.consensus.confidence,
      thesis: thesisFor(signal).slice(0, 1000),
      invalidation: invalidationFor(signal).slice(0, 1000),
      source_snapshot_at: signal.market.observed_at,
      entry_price: signal.market.price_usd,
      metadata: { findings: signal.consensus.findings },
    };
  });
  const response = await new SupabaseGateway(env).insertIgnoringDuplicates(
    "opportunity_signals",
    rows,
    "fingerprint",
  );
  const persisted = (await response.json()) as unknown[];
  return {
    recorded: persisted.length,
    skipped: signals.length - eligible.length,
  };
}

export async function readJournal(env: Env, limit: number) {
  const response = await new SupabaseGateway(env).opportunityJournal(limit);
  const records = (await response.json()) as Array<Record<string, unknown>>;
  return { records, count: records.length };
}

/** Evaluates each eligible outcome once, against a current same-provider price. */
export async function evaluateJournal(env: Env, rows: MarketRow[]) {
  const db = new SupabaseGateway(env);
  const currentByAsset = new Map<string, MarketRow>();
  for (const row of rows) {
    if (!row.price_usd || row.price_usd <= 0) continue;
    const key = `${row.provider}:${row.name.trim().toLowerCase()}`;
    const existing = currentByAsset.get(key);
    if (!existing || row.observed_at > existing.observed_at)
      currentByAsset.set(key, row);
  }
  const response = await db.pendingJournalSignals(250);
  const pending = (await response.json()) as Array<{
    id: string;
    asset_key: string;
    created_at: string;
    entry_price: number;
    source_snapshot_at: string;
    horizon: OpportunityHorizon;
  }>;
  const now = Date.now();
  let evaluated = 0;
  let waiting = 0;

  for (const signal of pending) {
    const current = currentByAsset.get(signal.asset_key);
    if (!current) {
      waiting++;
      continue;
    }
    const sourceAt = Date.parse(current.observed_at);
    const age = now - sourceAt;
    if (!Number.isFinite(sourceAt) || age < 0 || age > MAX_EVALUATION_AGE_MS) {
      waiting++;
      continue;
    }
    const maturity = new Date(signal.source_snapshot_at).getTime();
    const due = HORIZON_CHECKPOINTS[signal.horizon].filter(
      (checkpoint) => maturity + CHECKPOINT_AGE_MS[checkpoint] <= now,
    );
    for (const checkpoint of due) {
      const existingResponse = await db.hasJournalEvaluation(
        signal.id,
        checkpoint,
      );
      const existing = (await existingResponse.json()) as unknown[];
      if (existing.length) continue;
      const returnPct =
        (current.price_usd! / Number(signal.entry_price) - 1) * 100;
      await db.insertIgnoringDuplicates(
        "opportunity_evaluations",
        [
          {
            signal_id: signal.id,
            checkpoint,
            evaluated_at: new Date().toISOString(),
            price: current.price_usd,
            return_pct: Number(returnPct.toFixed(6)),
            source_snapshot_at: current.observed_at,
          },
        ],
        "signal_id,checkpoint",
      );
      evaluated++;
    }
  }
  return { evaluated, waiting, checked: pending.length };
}
