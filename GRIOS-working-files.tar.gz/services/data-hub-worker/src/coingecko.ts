import type { CoinGeckoMarket, Env, NormalizedMarket } from "./types";

const MARKET_URL = "https://api.coingecko.com/api/v3/coins/markets";

export class ConnectorError extends Error {
  constructor(
    message: string,
    readonly retryable: boolean,
  ) {
    super(message);
    this.name = "ConnectorError";
  }
}

/** CoinGecko is isolated behind this connector so new providers share the hub contract. */
export async function fetchCoinGeckoMarkets(
  env: Env,
): Promise<CoinGeckoMarket[]> {
  const url = new URL(MARKET_URL);
  url.search = new URLSearchParams({
    vs_currency: "usd",
    order: "market_cap_desc",
    per_page: "250",
    page: "1",
    sparkline: "false",
    price_change_percentage: "24h,7d,30d",
    locale: "en",
  }).toString();

  const response = await fetch(url, {
    headers: {
      accept: "application/json",
      "x-cg-demo-api-key": env.COINGECKO_API_KEY,
    },
    signal: AbortSignal.timeout(15_000),
  });

  if (!response.ok) {
    throw new ConnectorError(
      `CoinGecko market request failed with HTTP ${response.status}.`,
      response.status === 429 || response.status >= 500,
    );
  }

  const payload: unknown = await response.json();
  if (!Array.isArray(payload)) {
    throw new ConnectorError(
      "CoinGecko returned an unexpected market payload.",
      false,
    );
  }

  return payload.filter(isCoinGeckoMarket);
}

export function normalizeCoinGeckoMarket(
  market: CoinGeckoMarket,
): NormalizedMarket {
  return {
    providerAssetId: market.id,
    symbol: market.symbol.toUpperCase(),
    name: market.name,
    imageUrl: market.image,
    observedAt: market.last_updated ?? new Date().toISOString(),
    priceUsd: market.current_price,
    marketCapUsd: market.market_cap,
    marketCapRank: market.market_cap_rank,
    volume24hUsd: market.total_volume,
    fdvUsd: market.fully_diluted_valuation,
    change24h: market.price_change_percentage_24h,
    change7d: market.price_change_percentage_7d_in_currency,
    change30d: market.price_change_percentage_30d_in_currency,
    rawPayload: market,
  };
}

function isCoinGeckoMarket(value: unknown): value is CoinGeckoMarket {
  if (typeof value !== "object" || value === null) return false;
  const market = value as Record<string, unknown>;
  return (
    typeof market.id === "string" &&
    typeof market.symbol === "string" &&
    typeof market.name === "string"
  );
}
