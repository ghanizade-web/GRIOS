import { ConnectorError } from "./coingecko";
import type { Env, NormalizedMarket } from "./types";

const LISTINGS_URL =
  "https://pro-api.coinmarketcap.com/v1/cryptocurrency/listings/latest";

interface CoinMarketCapListing {
  id: number;
  name: string;
  symbol: string;
  slug: string;
  cmc_rank: number | null;
  last_updated: string | null;
  quote: {
    USD?: {
      price?: number | null;
      volume_24h?: number | null;
      market_cap?: number | null;
      fully_diluted_market_cap?: number | null;
      percent_change_24h?: number | null;
      percent_change_7d?: number | null;
      percent_change_30d?: number | null;
      last_updated?: string | null;
    };
  };
}

/** Uses CoinMarketCap's authenticated listings endpoint; the key remains in a Worker secret. */
export async function fetchCoinMarketCapMarkets(
  env: Env,
): Promise<NormalizedMarket[]> {
  const url = new URL(LISTINGS_URL);
  url.search = new URLSearchParams({
    start: "1",
    limit: "250",
    convert: "USD",
  }).toString();
  const response = await fetch(url, {
    headers: {
      accept: "application/json",
      "X-CMC_PRO_API_KEY": env.COINMARKETCAP_API_KEY,
    },
    signal: AbortSignal.timeout(15_000),
  });
  if (!response.ok) {
    throw new ConnectorError(
      `CoinMarketCap market request failed with HTTP ${response.status}.`,
      response.status === 429 || response.status >= 500,
    );
  }
  const payload: unknown = await response.json();
  if (!isListingResponse(payload)) {
    throw new ConnectorError(
      "CoinMarketCap returned an unexpected market payload.",
      false,
    );
  }
  return payload.data.map(normalizeCoinMarketCapMarket);
}

function normalizeCoinMarketCapMarket(
  market: CoinMarketCapListing,
): NormalizedMarket {
  const usd = market.quote.USD;
  return {
    providerAssetId: String(market.id),
    symbol: market.symbol.toUpperCase(),
    name: market.name,
    imageUrl: null,
    observedAt:
      usd?.last_updated ?? market.last_updated ?? new Date().toISOString(),
    priceUsd: numberOrNull(usd?.price),
    marketCapUsd: numberOrNull(usd?.market_cap),
    marketCapRank: numberOrNull(market.cmc_rank),
    volume24hUsd: numberOrNull(usd?.volume_24h),
    fdvUsd: numberOrNull(usd?.fully_diluted_market_cap),
    change24h: numberOrNull(usd?.percent_change_24h),
    change7d: numberOrNull(usd?.percent_change_7d),
    change30d: numberOrNull(usd?.percent_change_30d),
    rawPayload: market,
  };
}

function isListingResponse(
  value: unknown,
): value is { data: CoinMarketCapListing[] } {
  if (typeof value !== "object" || value === null) return false;
  const data = (value as Record<string, unknown>).data;
  return (
    Array.isArray(data) &&
    data.every((item) => typeof item === "object" && item !== null)
  );
}

function numberOrNull(value: unknown): number | null {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
