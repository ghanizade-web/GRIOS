import { fetchCoinGeckoMarkets, normalizeCoinGeckoMarket } from "./coingecko";
import { fetchCoinMarketCapMarkets } from "./coinmarketcap";
import { SupabaseGateway } from "./supabase";
import type { AssetRecord, Env, NormalizedMarket } from "./types";

export interface IngestionResult {
  provider: string;
  runId: string;
  assetCount: number;
  snapshotCount: number;
  completedAt: string;
}

interface SourceDefinition {
  slug: string;
  displayName: string;
  fetchMarkets: (env: Env) => Promise<NormalizedMarket[]>;
}

const sources: readonly SourceDefinition[] = [
  {
    slug: "coingecko",
    displayName: "CoinGecko",
    fetchMarkets: async (env) =>
      (await fetchCoinGeckoMarkets(env)).map(normalizeCoinGeckoMarket),
  },
  {
    slug: "coinmarketcap",
    displayName: "CoinMarketCap",
    fetchMarkets: fetchCoinMarketCapMarkets,
  },
];

export function ingestAllSources(
  env: Env,
): Promise<PromiseSettledResult<IngestionResult>[]> {
  return Promise.allSettled(sources.map((source) => ingestSource(env, source)));
}

async function ingestSource(
  env: Env,
  definition: SourceDefinition,
): Promise<IngestionResult> {
  const db = new SupabaseGateway(env);
  const runId = crypto.randomUUID();
  const startedAt = new Date().toISOString();
  const sourceResponse = await db.upsert(
    "data_sources",
    {
      slug: definition.slug,
      display_name: definition.displayName,
      status: "running",
      last_started_at: startedAt,
    },
    "slug",
  );
  const [source] = (await sourceResponse.json()) as Array<{ id: string }>;
  if (!source)
    throw new Error(`${definition.displayName} source was not persisted.`);

  try {
    const markets = await definition.fetchMarkets(env);
    const assetsResponse = await db.upsert(
      "assets",
      markets.map((market) => toAsset(definition.slug, market)),
      "provider,provider_asset_id",
    );
    const persistedAssets = (await assetsResponse.json()) as AssetRecord[];
    const assetIdByProviderId = new Map(
      persistedAssets.map((asset) => [asset.provider_asset_id, asset.id]),
    );
    const snapshots = markets.flatMap((market) => {
      const assetId = assetIdByProviderId.get(market.providerAssetId);
      return assetId ? [toSnapshot(market, assetId, source.id)] : [];
    });
    await db.insert("market_snapshots", snapshots);

    const completedAt = new Date().toISOString();
    await db.insert("ingestion_runs", {
      id: runId,
      source_id: source.id,
      status: "succeeded",
      started_at: startedAt,
      completed_at: completedAt,
      records_received: markets.length,
      records_written: snapshots.length,
    });
    await db.upsert(
      "data_sources",
      {
        slug: definition.slug,
        display_name: definition.displayName,
        status: "healthy",
        last_success_at: completedAt,
        last_started_at: startedAt,
        last_error: null,
      },
      "slug",
    );
    return {
      provider: definition.slug,
      runId,
      assetCount: markets.length,
      snapshotCount: snapshots.length,
      completedAt,
    };
  } catch (error) {
    const detail =
      error instanceof Error ? error.message : "Unknown ingestion error.";
    await db
      .insert("ingestion_runs", {
        id: runId,
        source_id: source.id,
        status: "failed",
        started_at: startedAt,
        completed_at: new Date().toISOString(),
        error_detail: detail.slice(0, 500),
      })
      .catch((writeError: unknown) =>
        console.error("ingestion-failure-audit-write-failed", writeError),
      );
    await db
      .upsert(
        "data_sources",
        {
          slug: definition.slug,
          display_name: definition.displayName,
          status: "degraded",
          last_error: detail.slice(0, 500),
          last_started_at: startedAt,
        },
        "slug",
      )
      .catch((writeError: unknown) =>
        console.error("source-status-write-failed", writeError),
      );
    throw error;
  }
}

function toAsset(provider: string, market: NormalizedMarket) {
  return {
    provider,
    provider_asset_id: market.providerAssetId,
    symbol: market.symbol,
    name: market.name,
    image_url: market.imageUrl,
    is_active: true,
  };
}

function toSnapshot(
  market: NormalizedMarket,
  assetId: string,
  sourceId: string,
) {
  return {
    asset_id: assetId,
    source_id: sourceId,
    observed_at: market.observedAt,
    price_usd: market.priceUsd,
    market_cap_usd: market.marketCapUsd,
    market_cap_rank: market.marketCapRank,
    volume_24h_usd: market.volume24hUsd,
    fdv_usd: market.fdvUsd,
    change_24h: market.change24h,
    change_7d: market.change7d,
    change_30d: market.change30d,
    raw_payload: market.rawPayload,
  };
}
